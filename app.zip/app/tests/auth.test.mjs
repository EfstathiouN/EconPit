import 'fake-indexeddb/auto';
import { webcrypto } from 'node:crypto';
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
if (!globalThis.crypto?.subtle) Object.defineProperty(globalThis,'crypto',{value:webcrypto,configurable:true});
globalThis.window={addEventListener(){},dispatchEvent(){}};
globalThis.document={addEventListener(){}};

const auth = await import('../js/auth.js');
const db   = await import('../js/db.js');

let pass=0,fail=0;
const check=(n,ok)=>{ok?pass++:fail++;console.log(`${ok?'✓':'✗'} ${n}`);};

check('η πρώτη εκκίνηση ζητά ρύθμιση', await auth.needsSetup() === true);

await auth.createLocalOwner({ name:'Θανάσης', email:'Test@Example.com ', password:'kalikodikos8' });
check('ο χρήστης συνδέθηκε', auth.user()?.name === 'Θανάσης');
check('πήρε ρόλο ιδιοκτήτη', auth.isOwner());
check('το email πεζοποιήθηκε', auth.user().email === 'test@example.com');
check('δεν ξαναζητά ρύθμιση', await auth.needsSetup() === false);

const stored = await db.meta.get('local_account');
check('ο κωδικός δεν αποθηκεύτηκε καθαρός', !JSON.stringify(stored).includes('kalikodikos8'));
check('αποθηκεύτηκε αποτύπωμα και αλάτι', !!stored.hash && !!stored.salt && stored.hash.length===64);

const profile = (await db.all('profiles'))[0];
check('δημιουργήθηκε προφίλ', profile?.role === 'owner');

await auth.signOut();
check('η αποσύνδεση καθάρισε τον χρήστη', auth.user() === null);
check('τα δεδομένα έμειναν', (await db.all('profiles')).length === 1);

try { await auth.signIn('test@example.com','lathoskodikos'); check('λάθος κωδικός απορρίπτεται', false); }
catch { check('λάθος κωδικός απορρίπτεται', true); }

await auth.signIn(' TEST@example.com ','kalikodikos8');
check('σωστός κωδικός περνάει', auth.user()?.name === 'Θανάσης');

check('έλεγχος δικαιωμάτων: owner', auth.can(['owner']) === true);
check('έλεγχος δικαιωμάτων: μόνο staff', auth.can(['staff']) === false);

const restored = await auth.restore();
check('η συνεδρία επανέρχεται μετά από επαναφόρτωση', restored?.id === profile.id);

try { await auth.createLocalOwner({name:'X',email:'x@y.gr',password:'short'}); check('κοντός κωδικός απορρίπτεται', false); }
catch { check('κοντός κωδικός απορρίπτεται', true); }

console.log(`\n${pass} πέρασαν, ${fail} απέτυχαν`);
process.exit(fail?1:0);
