import { menuFor, flatItems, findItem, homeFor } from '../js/menu.js';

// 1. Ο υπάλληλος βλέπει μόνο όσα του αναλογούν
const staff = menuFor('staff');
const staffKeys = staff.flatMap(e => e.type === 'group' ? e.items.map(i=>i.key) : (e.type==='item'?[e.key]:[]));
console.log('Υπάλληλος βλέπει:', staffKeys);

const owner = menuFor('owner');
const ownerKeys = owner.flatMap(e => e.type === 'group' ? e.items.map(i=>i.key) : (e.type==='item'?[e.key]:[]));
console.log('Ιδιοκτήτης βλέπει:', ownerKeys.length, 'οθόνες');

// 2. Δεν μένουν ορφανοί τίτλοι ενοτήτων στο μενού του υπαλλήλου
const dividers = staff.filter(e=>e.type==='divider').map(e=>e.label);
console.log('Τίτλοι ενοτήτων υπαλλήλου:', dividers);

// 3. Κανένα διπλό key
const keys = flatItems().map(i=>i.key);
const dupes = keys.filter((k,i)=>keys.indexOf(k)!==i);
console.log('Διπλά keys:', dupes.length ? dupes : 'κανένα');

// 4. Αρχική ανά ρόλο υπάρχει και είναι ορατή
for (const role of ['owner','staff']) {
  const home = homeFor(role);
  const item = findItem(home);
  console.log(`Αρχική ${role}: ${home} → ${item ? (item.roles.includes(role)?'ορατή':'ΚΡΥΦΗ!') : 'ΔΕΝ ΥΠΑΡΧΕΙ!'}`);
}
