import 'fake-indexeddb/auto';
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
globalThis.window = { dispatchEvent(){}, addEventListener(){} };
globalThis.document = { addEventListener(){}, visibilityState:'visible' };
globalThis.CustomEvent = class { constructor(t,o){ this.type=t; Object.assign(this,o);} };

const db = await import('../js/db.js');

let pass=0, fail=0;
const check = (name, ok) => { ok ? pass++ : fail++; console.log(`${ok?'✓':'✗'} ${name}`); };

// --- 1. Γράψιμο βάζει τα πεδία υποδομής και μπαίνει στην ουρά
const rec = await db.put('cafe_daily', { date:'2026-09-08', turnover:1200, card:800, z_reading:1150 }, { user_id:'u1' });
check('το id δημιουργείται', !!rec.id);
check('μπαίνει updated_at', !!rec.updated_at);
check('deleted είναι false', rec.deleted === false);
check('καταγράφεται η συσκευή', !!rec.device_id);
check('καταγράφεται ο χρήστης', rec.created_by === 'u1');
check('η εγγραφή μπήκε στην ουρά', (await db.outbox.count()) === 1);

// --- 2. Ανάγνωση
const back = await db.get('cafe_daily', rec.id);
check('διαβάζεται πίσω σωστά', back.turnover === 1200 && back.z_reading === 1150);

// --- 3. Ενημέρωση ίδιας ημέρας δεν φτιάχνει δεύτερη γραμμή
await new Promise(r=>setTimeout(r,5));
await db.put('cafe_daily', { ...back, turnover: 1300 }, { user_id:'u1' });
const rows = await db.all('cafe_daily');
check('η ενημέρωση δεν διπλασιάζει γραμμή', rows.length === 1 && rows[0].turnover === 1300);
check('το updated_at προχώρησε', rows[0].updated_at > rec.updated_at);

// --- 4. Διαγραφή με σήμανση
await db.remove('cafe_daily', rec.id, { user_id:'u1' });
check('η διαγραμμένη κρύβεται', (await db.all('cafe_daily')).length === 0);
check('η γραμμή υπάρχει ακόμα για να ταξιδέψει', (await db.all('cafe_daily',{includeDeleted:true})).length === 1);

// --- 5. Ευρετήρια
await db.put('suppliers', { name:'Γαλακτοκομικά ΑΕ' });
await db.put('suppliers', { name:'Καφές ΕΠΕ' });
check('αναζήτηση με ευρετήριο', (await db.byIndex('suppliers','name','Καφές ΕΠΕ')).length === 1);

// --- 6. changedSince
const cutoff = new Date(Date.now()-1000).toISOString();
check('φέρνει τις πρόσφατες αλλαγές', (await db.changedSince('suppliers', cutoff)).length === 2);

// --- 7. Καθαρισμός κρατάει την ταυτότητα συσκευής
const devBefore = await db.deviceId();
await db.wipe();
check('η βάση άδειασε', (await db.all('suppliers')).length === 0);
check('η ουρά άδειασε', (await db.outbox.count()) === 0);
check('η ταυτότητα συσκευής κρατήθηκε', (await db.deviceId()) === devBefore);

console.log(`\n${pass} πέρασαν, ${fail} απέτυχαν`);
process.exit(fail ? 1 : 0);
