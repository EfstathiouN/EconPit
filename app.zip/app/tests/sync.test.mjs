import 'fake-indexeddb/auto';
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
const handlers = {};
globalThis.window = { dispatchEvent(e){ (handlers[e.type]||[]).forEach(f=>f(e)); }, addEventListener(t,f){ (handlers[t]??=[]).push(f); } };
globalThis.document = { addEventListener(){}, visibilityState:'visible' };
globalThis.CustomEvent = class { constructor(t,o){ this.type=t; Object.assign(this,o);} };

const { CONFIG } = await import('../js/config.js');
CONFIG.SUPABASE.url = 'https://fake.supabase.co';
CONFIG.SUPABASE.anonKey = 'anon';

const db   = await import('../js/db.js');
const api  = await import('../js/api.js');
const sync = await import('../js/sync.js');

// ---- ψεύτικος server ----
const server = {};                       // table -> id -> record
let pushCalls = 0;
globalThis.fetch = async (url, opts={}) => {
  const u = new URL(url);
  if (u.pathname.startsWith('/rest/v1/')) {
    const table = u.pathname.split('/')[3];
    if (opts.method === 'POST') {
      pushCalls++;
      for (const r of JSON.parse(opts.body)) (server[table] ??= {})[r.id] = r;
      return { ok:true, status:204, text: async()=>'' };
    }
    const since = u.searchParams.get('updated_at')?.replace('gt.','');
    const rows = Object.values(server[table] ?? {})
      .filter(r => !since || r.updated_at > since)
      .sort((a,b)=>a.updated_at.localeCompare(b.updated_at));
    return { ok:true, status:200, text: async()=>JSON.stringify(rows) };
  }
  throw new Error('unexpected '+url);
};

await db.meta.set('session', { access_token:'t', refresh_token:'r', expires_at: Date.now()+3600e3, user:{id:'u1'} });
await api.loadSession();

let pass=0, fail=0;
const check = (n,ok) => { ok?pass++:fail++; console.log(`${ok?'✓':'✗'} ${n}`); };

// 1. Η ουρά φεύγει προς τον server
const a = await db.put('cafe_daily', { date:'2026-09-01', turnover:100, card:60, z_reading:95 }, { user_id:'u1' });
const b = await db.put('cafe_daily', { date:'2026-09-02', turnover:200, card:120, z_reading:190 }, { user_id:'u1' });
let res = await sync.run();
check('στάλθηκαν και οι δύο εγγραφές', res.sent === 2);
check('η ουρά άδειασε', (await db.outbox.count()) === 0);
check('ο server τις έχει', Object.keys(server.cafe_daily).length === 2);

// 2. Πολλαπλές αλλαγές της ίδιας εγγραφής στέλνονται μία φορά
await db.put('cafe_daily', { ...a, turnover:110 }, { user_id:'u1' });
await db.put('cafe_daily', { ...a, turnover:120 }, { user_id:'u1' });
const before = pushCalls;
res = await sync.run();
check('η ίδια εγγραφή συμπτύσσεται σε μία αποστολή', res.sent === 1);
check('ο server έχει την τελευταία τιμή', server.cafe_daily[a.id].turnover === 120);

// 3. Άλλη συσκευή γράφει → κατεβαίνει σε εμάς
server.cafe_daily['remote-1'] = {
  id:'remote-1', date:'2026-09-03', turnover:300, card:150, z_reading:290,
  updated_at:new Date(Date.now()+1000).toISOString(), deleted:false, device_id:'zzz', created_by:'u2'
};
res = await sync.run();
check('η ξένη εγγραφή κατέβηκε', res.received === 1);
check('αποθηκεύτηκε τοπικά', !!(await db.get('cafe_daily','remote-1')));

// 4. Παλιότερη εκδοχή δεν πατάει νεότερη τοπική
const local = await db.get('cafe_daily', b.id);
server.cafe_daily[b.id] = { ...local, turnover:999, updated_at:new Date(Date.now()-9e6).toISOString() };
await db.meta.remove('cursor:cafe_daily');       // ξανακατεβάζουμε τα πάντα
await sync.run();
check('η παλιά εκδοχή αγνοήθηκε', (await db.get('cafe_daily', b.id)).turnover === 200);

// 5. Νεότερη απομακρυσμένη κερδίζει
server.cafe_daily[b.id] = { ...local, turnover:777, updated_at:new Date(Date.now()+5000).toISOString() };
await db.meta.remove('cursor:cafe_daily');
await sync.run();
check('η νεότερη εκδοχή πέρασε', (await db.get('cafe_daily', b.id)).turnover === 777);

// 6. Χωρίς δίκτυο δεν πετάει, απλώς περιμένει
Object.defineProperty(globalThis,'navigator',{value:{onLine:false},configurable:true});
await db.put('cafe_daily', { date:'2026-09-04', turnover:400, card:200, z_reading:390 }, { user_id:'u1' });
res = await sync.run();
check('εκτός δικτύου δεν προσπαθεί', res.skipped === 'offline');
check('η εγγραφή περιμένει στην ουρά', (await db.outbox.count()) === 1);
check('η κατάσταση δείχνει χωρίς δίκτυο', sync.getState().state === 'offline');

// 7. Επιστροφή δικτύου → φεύγει μόνη της
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
res = await sync.run();
check('με την επιστροφή του δικτύου στάλθηκε', res.sent === 1 && (await db.outbox.count()) === 0);

console.log(`\n${pass} πέρασαν, ${fail} απέτυχαν`);
process.exit(fail?1:0);
