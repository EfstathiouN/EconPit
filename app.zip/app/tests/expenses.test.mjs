/** Λογική εξόδων: ιεραρχία κατηγοριών και εκκρεμή πάγια. */
import 'fake-indexeddb/auto';
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
globalThis.window={addEventListener(){},dispatchEvent(){}};
globalThis.document={addEventListener(){}};

let pass=0,fail=0;
const check=(n,ok,extra='')=>{ok?pass++:fail++;console.log(`${ok?'✓':'✗'} ${n}${extra?' → '+extra:''}`);};

const { categoryTree, categoryName } = await import('../js/views/expenses.js');
const { pendingRecurring } = await import('../js/views/recurring.js');

// ---------- ιεραρχία κατηγοριών ----------
const cats = [
  { id:'a', name:'Τροφοδοσία', business:'cafe' },
  { id:'b', name:'Γαλακτοκομικά', business:'cafe', parent_id:'a' },
  { id:'c', name:'Κρεατικά', business:'cafe', parent_id:'a' },
  { id:'d', name:'Ενοίκιο', business:null },
  { id:'e', name:'Εξοπλισμός', business:'video' },
  { id:'f', name:'Παλιά', business:'cafe', active:false }
];

const tree = categoryTree(cats);
check('οι κύριες κατηγορίες μπαίνουν αλφαβητικά',
      tree.filter(c=>!c.depth).map(c=>c.name).join(',') === 'Ενοίκιο,Εξοπλισμός,Τροφοδοσία',
      tree.filter(c=>!c.depth).map(c=>c.name).join(','));
check('τα παιδιά ακολουθούν αμέσως τον γονιό τους',
      tree.map(c=>c.id).join(',') === 'd,e,a,b,c', tree.map(c=>c.id).join(','));
check('τα παιδιά παίρνουν βάθος 1', tree.find(c=>c.id==='b').depth === 1);
check('οι ανενεργές δεν εμφανίζονται', !tree.some(c=>c.id==='f'));
check('φιλτράρισμα ανά επιχείρηση κρατά και τις κοινές',
      categoryTree(cats,'cafe').map(c=>c.id).sort().join('') === 'abcd');
check('η επιχείρηση βίντεο δεν βλέπει κατηγορίες του καφέ',
      !categoryTree(cats,'video').some(c=>c.id==='a'));
check('όνομα κατηγορίας από id', categoryName(cats,'b') === 'Γαλακτοκομικά');
check('άγνωστο id δίνει παύλα', categoryName(cats,'zzz') === '—');

// ---------- εκκρεμή πάγια ----------
const templates = [
  { id:'t1', name:'Ενοίκιο', day_of_month:5, business:'cafe' },
  { id:'t2', name:'ΔΕΗ', day_of_month:20, business:'cafe' },
  { id:'t3', name:'Παλιά συνδρομή', day_of_month:1, business:'cafe', active:false }
];
const expenses = [
  { id:'e1', recurring_id:'t1', date:'2026-09-05', amount:800 }
];

const pending = pendingRecurring(templates, expenses, '2026-09', '2026-09-25');
check('το πληρωμένο πάγιο φεύγει από τα εκκρεμή', !pending.some(p=>p.id==='t1'));
check('το απλήρωτο μένει', pending.some(p=>p.id==='t2'));
check('το ανενεργό αγνοείται', !pending.some(p=>p.id==='t3'));
check('σημαδεύεται ως καθυστερημένο όταν πέρασε η ημέρα',
      pending.find(p=>p.id==='t2').overdue === true);

const early = pendingRecurring(templates, expenses, '2026-09', '2026-09-10');
check('δεν είναι καθυστερημένο πριν την ημέρα του',
      early.find(p=>p.id==='t2').overdue === false);

const other = pendingRecurring(templates, expenses, '2026-10', '2026-09-25');
check('άλλος μήνας ξαναζητά όλα τα ενεργά', other.length === 2);

check('η σειρά ακολουθεί την ημέρα του μήνα',
      pendingRecurring(templates, [], '2026-09','2026-09-25').map(p=>p.id).join(',') === 't1,t2');

console.log(`\n${pass} πέρασαν, ${fail} απέτυχαν`);
process.exit(fail?1:0);
