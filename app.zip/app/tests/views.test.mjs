/** Ελέγχει ότι όλα τα modules φορτώνουν και ότι μενού και οθόνες συμφωνούν. */
import 'fake-indexeddb/auto';
Object.defineProperty(globalThis,'navigator',{value:{onLine:true},configurable:true});
globalThis.window={addEventListener(){},dispatchEvent(){}};
globalThis.document={addEventListener(){},createElement:()=>({}),getElementById:()=>null};

let pass=0,fail=0;
const check=(n,ok,extra='')=>{ok?pass++:fail++;console.log(`${ok?'✓':'✗'} ${n}${extra?' → '+extra:''}`);};

const { VIEWS, placeholderView } = await import('../js/views/index.js');
const { flatItems, findItem } = await import('../js/menu.js');

check('όλα τα modules φόρτωσαν', true);

// Κάθε οθόνη αντιστοιχεί σε καρτέλα του μενού
const orphans = Object.keys(VIEWS).filter(k => !findItem(k));
check('καμία οθόνη χωρίς θέση στο μενού', orphans.length === 0, orphans.join(', '));

// Κάθε οθόνη έχει τίτλο και mount
const broken = Object.entries(VIEWS).filter(([,v]) => !v.title || typeof v.mount !== 'function');
check('κάθε οθόνη έχει τίτλο και mount', broken.length === 0, broken.map(b=>b[0]).join(', '));

// Οι δύο οθόνες εξόδων είναι ξεχωριστά αντικείμενα με διαφορετικό τίτλο
check('η κοινή και η οθόνη καφέ δεν μπερδεύονται',
      VIEWS['expenses'] !== VIEWS['cafe/expenses'] &&
      VIEWS['expenses'].title !== VIEWS['cafe/expenses'].title);

// Οι μη υλοποιημένες δίνουν οθόνη αναμονής με φάση
const notReady = flatItems().filter(i => !VIEWS[i.key]);
const withoutPhase = notReady.filter(i => !i.phase);
check('κάθε ανυλοποίητη καρτέλα δηλώνει φάση', withoutPhase.length === 0);
check(`${notReady.length} καρτέλες σε αναμονή, ${Object.keys(VIEWS).length} έτοιμες`, true);

const ph = placeholderView('rooms/bookings');
check('η οθόνη αναμονής παίρνει τίτλο από το μενού', ph.title === 'Κρατήσεις');

// Ο υπάλληλος δεν έχει πρόσβαση σε οθόνη εξόδων
const staffCan = k => (findItem(k)?.roles || []).includes('staff');
check('ο υπάλληλος δεν βλέπει έξοδα', !staffCan('expenses') && !staffCan('cafe/expenses'));
check('ο υπάλληλος δεν βλέπει τις κινήσεις βίντεο', !staffCan('video/ledger'));

console.log(`\n${pass} πέρασαν, ${fail} απέτυχαν`);
process.exit(fail?1:0);
