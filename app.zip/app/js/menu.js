/**
 * Το μενού. Μία λίστα, ένα σημείο αλλαγής.
 *
 * Κάθε καρτέλα δηλώνει ποιοι ρόλοι τη βλέπουν. Ο υπάλληλος δεν παίρνει
 * κρυμμένη έκδοση της οθόνης: η καρτέλα δεν μπαίνει καν στο μενού του και ο
 * δρομολογητής αρνείται τη διεύθυνση.
 *
 * Το πεδίο phase δείχνει πότε υλοποιείται. Όσες δεν έχουν έρθει ακόμα
 * εμφανίζουν οθόνη αναμονής αντί για σπασμένο σύνδεσμο.
 */
const OWNER = ['owner'];
const BOTH  = ['owner', 'staff'];

export const MENU = [
  { type: 'item', key: 'dashboard', label: 'Πίνακας ελέγχου', icon: 'home', roles: OWNER, phase: 7 },

  { type: 'divider', label: 'Καφετέρια' },
  {
    type: 'group', label: 'Ταμείο', roles: OWNER, items: [
      { key: 'cafe/daily', label: 'Ημερήσιο ταμείο', icon: 'cash', roles: OWNER, phase: 2, ready: true }
    ]
  },
  {
    type: 'group', label: 'Προμηθευτές', roles: BOTH, items: [
      { key: 'cafe/suppliers', label: 'Προμηθευτές',      icon: 'truck', roles: OWNER, phase: 3 },
      { key: 'cafe/invoices',  label: 'Τιμολόγια',        icon: 'file',  roles: BOTH,  phase: 3, badge: 'invoices' },
      { key: 'cafe/orders',    label: 'Λίστες παραγγελίας', icon: 'list', roles: BOTH,  phase: 4 }
    ]
  },
  {
    type: 'group', label: 'Κοστολόγηση', roles: BOTH, items: [
      { key: 'cafe/products', label: 'Πρώτες ύλες',     icon: 'box',   roles: BOTH,  phase: 5 },
      { key: 'cafe/recipes',  label: 'Συνταγές',        icon: 'list',  roles: OWNER, phase: 5 },
      { key: 'cafe/foodcost', label: 'Food cost',       icon: 'chart', roles: OWNER, phase: 5 },
      { key: 'cafe/prices',   label: 'Ιστορικό τιμών',  icon: 'chart', roles: OWNER, phase: 5 }
    ]
  },
  { type: 'item', key: 'cafe/expenses', label: 'Έξοδα καφετέριας', icon: 'coins', roles: OWNER, phase: 2 },
  { type: 'item', key: 'cafe/staff',    label: 'Προσωπικό',        icon: 'users', roles: OWNER, phase: 6 },

  { type: 'divider', label: 'Βίντεο' },
  { type: 'item', key: 'video/ledger', label: 'Κινήσεις', icon: 'video', roles: OWNER, phase: 2 },

  { type: 'divider', label: 'Καταλύματα' },
  {
    type: 'group', label: 'Κρατήσεις', roles: OWNER, items: [
      { key: 'rooms/bookings', label: 'Κρατήσεις',       icon: 'calendar', roles: OWNER, phase: 6 },
      { key: 'rooms/direct',   label: 'Άμεσες κρατήσεις', icon: 'calendar', roles: OWNER, phase: 6 },
      { key: 'rooms/guests',   label: 'Επισκέπτες',      icon: 'users',    roles: OWNER, phase: 6 }
    ]
  },
  {
    type: 'group', label: 'Φορολογικά', roles: OWNER, items: [
      { key: 'rooms/takk',    label: 'ΤΑΚΚ & ΕΟΤ', icon: 'file',  roles: OWNER, phase: 6 },
      { key: 'rooms/tax',     label: 'Φόρος',      icon: 'coins', roles: OWNER, phase: 6 },
      { key: 'rooms/pricing', label: 'Τιμολόγηση', icon: 'chart', roles: OWNER, phase: 6 },
      { key: 'rooms/invoices', label: 'Τιμολόγια', icon: 'file',  roles: OWNER, phase: 6 }
    ]
  },
  {
    type: 'group', label: 'Ζημιές & αποζημιώσεις', roles: OWNER, items: [
      { key: 'rooms/damages', label: 'Ζημιές',      icon: 'file',  roles: OWNER, phase: 6 },
      { key: 'rooms/claims',  label: 'Αποζημιώσεις', icon: 'coins', roles: OWNER, phase: 6 }
    ]
  },
  { type: 'item', key: 'rooms/services', label: 'Υπηρεσίες & δραστηριότητες', icon: 'box',   roles: OWNER, phase: 6 },
  { type: 'item', key: 'rooms/stats',    label: 'Στατιστικά',                 icon: 'chart', roles: OWNER, phase: 6 },

  { type: 'divider', label: 'Κοινά' },
  { type: 'item', key: 'properties', label: 'Ακίνητα & χώροι', icon: 'bed', roles: OWNER, phase: 6 },
  {
    type: 'group', label: 'Έξοδα & λειτουργία', roles: OWNER, items: [
      { key: 'expenses',            label: 'Όλα τα έξοδα',     icon: 'coins', roles: OWNER, phase: 2 },
      { key: 'expenses/categories', label: 'Κατηγορίες εξόδων', icon: 'list',  roles: OWNER, phase: 2 },
      { key: 'expenses/recurring',  label: 'Πάγια & συνδρομές', icon: 'refresh', roles: OWNER, phase: 2 },
      { key: 'maintenance',         label: 'Συντήρηση',        icon: 'settings', roles: OWNER, phase: 6 },
      { key: 'craftsmen',           label: 'Μάστορες',         icon: 'users', roles: OWNER, phase: 6 }
    ]
  },
  {
    type: 'group', label: 'Αρχείο', roles: OWNER, items: [
      { key: 'documents', label: 'Έγγραφα',    icon: 'file', roles: OWNER, phase: 6 },
      { key: 'notes',     label: 'Σημειώσεις', icon: 'list', roles: OWNER, phase: 6 }
    ]
  },
  { type: 'item', key: 'reports', label: 'Αναφορές', icon: 'chart', roles: OWNER, phase: 7 },
  {
    type: 'group', label: 'Σύστημα', roles: OWNER, items: [
      { key: 'system/users',    label: 'Χρήστες & δικαιώματα', icon: 'users',    roles: OWNER, phase: 1, ready: true },
      { key: 'system/settings', label: 'Ρυθμίσεις',            icon: 'settings', roles: OWNER, phase: 1, ready: true },
      { key: 'system/backup',   label: 'Αντίγραφα',            icon: 'save',     roles: OWNER, phase: 7 },
      { key: 'system/sync',     label: 'Συγχρονισμός',         icon: 'refresh',  roles: OWNER, phase: 1, ready: true }
    ]
  }
];

/** Επίπεδη λίστα καρτελών, για τον δρομολογητή. */
export function flatItems() {
  const out = [];
  for (const entry of MENU) {
    if (entry.type === 'item') out.push(entry);
    if (entry.type === 'group') out.push(...entry.items);
  }
  return out;
}

export function findItem(key) {
  return flatItems().find((i) => i.key === key) || null;
}

/** Το μενού όπως το βλέπει ο συγκεκριμένος ρόλος. */
export function menuFor(role) {
  const visible = (roles) => !roles || roles.includes(role);
  const out = [];

  for (const entry of MENU) {
    if (entry.type === 'divider') { out.push(entry); continue; }
    if (entry.type === 'item') { if (visible(entry.roles)) out.push(entry); continue; }

    const items = entry.items.filter((i) => visible(i.roles));
    if (items.length) out.push({ ...entry, items });
  }

  // Χωρίζουμε τους τίτλους ενοτήτων που έμειναν χωρίς περιεχόμενο.
  return out.filter((entry, i) => {
    if (entry.type !== 'divider') return true;
    const next = out[i + 1];
    return next && next.type !== 'divider';
  });
}

/** Πού προσγειώνεται ο καθένας μετά την είσοδο. */
export const homeFor = (role) => (role === 'owner' ? 'dashboard' : 'cafe/invoices');
