/**
 * Εκκίνηση, οθόνες εισόδου, κέλυφος και δρομολόγηση.
 */
import { CONFIG, isSyncConfigured } from './config.js';
import * as db from './db.js';
import * as auth from './auth.js';
import * as sync from './sync.js';
import { menuFor, findItem, homeFor } from './menu.js';
import { VIEWS, placeholderView } from './views.js';
import { esc, el, icon, toast } from './ui.js';

const root = document.getElementById('root');
let repaintView = null;

/* ================================================================== */
/* Πρώτη ρύθμιση                                                       */
/* ================================================================== */

function screenSetup() {
  root.innerHTML = `
    <div class="login-wrap">
      <div class="login-box">
        <div class="login-logo">${icon('lock', 22)}</div>
        <h1>Πρώτη ρύθμιση</h1>
        <p class="sub">Φτιάξε τον λογαριασμό ιδιοκτήτη για αυτή τη συσκευή.</p>
        <div id="msg"></div>
        <form id="setupForm" autocomplete="off">
          <div class="field"><label for="sName">Όνομα</label>
            <input id="sName" required></div>
          <div class="field"><label for="sEmail">Email</label>
            <input id="sEmail" type="email" required></div>
          <div class="field"><label for="sPass">Κωδικός</label>
            <input id="sPass" type="password" required minlength="8">
            <div class="hint">Τουλάχιστον 8 χαρακτήρες. Δεν αποθηκεύεται σε καθαρή μορφή.</div></div>
          <button type="submit" class="btn btn-primary btn-full">Δημιουργία λογαριασμού</button>
        </form>
      </div>
    </div>`;

  document.getElementById('setupForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const box = document.getElementById('msg');
    try {
      await auth.createLocalOwner({
        name: document.getElementById('sName').value,
        email: document.getElementById('sEmail').value,
        password: document.getElementById('sPass').value
      });
      await startApp();
    } catch (err) {
      box.innerHTML = `<div class="msg error">${esc(err.message)}</div>`;
    }
  });
}

/* ================================================================== */
/* Είσοδος                                                             */
/* ================================================================== */

function screenLogin() {
  root.innerHTML = `
    <div class="login-wrap">
      <div class="login-box">
        <div class="login-logo">${icon('lock', 22)}</div>
        <h1>${esc(CONFIG.APP_NAME)}</h1>
        <p class="sub">${esc(CONFIG.APP_SHORT)}</p>
        <div id="msg"></div>
        <form id="loginForm" autocomplete="on">
          <div class="field"><label for="lEmail">Email</label>
            <input id="lEmail" type="email" autocomplete="username" required></div>
          <div class="field"><label for="lPass">Κωδικός</label>
            <input id="lPass" type="password" autocomplete="current-password" required></div>
          <button type="submit" class="btn btn-primary btn-full" id="lBtn">Είσοδος</button>
        </form>
        ${navigator.onLine ? '' : `
          <div class="msg warn" style="margin-top:14px">
            Χωρίς δίκτυο. Μπορούν να μπουν όσοι έχουν ξανασυνδεθεί σε αυτή τη συσκευή.
          </div>`}
      </div>
    </div>`;

  document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('lBtn');
    const box = document.getElementById('msg');
    btn.disabled = true;
    btn.textContent = 'Γίνεται έλεγχος…';

    try {
      await auth.signIn(
        document.getElementById('lEmail').value,
        document.getElementById('lPass').value
      );
      await startApp();
    } catch (err) {
      box.innerHTML = `<div class="msg error">${esc(err.message)}</div>`;
      btn.disabled = false;
      btn.textContent = 'Είσοδος';
    }
  });
}

/* ================================================================== */
/* Κέλυφος                                                             */
/* ================================================================== */

function navMarkup(role) {
  return menuFor(role).map((entry) => {
    if (entry.type === 'divider') {
      return `<div class="nav-div">${esc(entry.label)}</div>`;
    }

    if (entry.type === 'item') {
      return `<div class="nav-solo">${itemMarkup(entry)}</div>`;
    }

    return `
      <details class="nav-grp">
        <summary>${esc(entry.label)}</summary>
        ${entry.items.map(itemMarkup).join('')}
      </details>`;
  }).join('');
}

function itemMarkup(item) {
  return `
    <button class="nav-item" data-key="${esc(item.key)}">
      ${icon(item.icon || 'box')}
      <span>${esc(item.label)}</span>
    </button>`;
}

function screenShell() {
  const me = auth.user();
  const initials = (me.name || '?').trim().charAt(0).toUpperCase();

  root.innerHTML = `
    <div class="sidebar-overlay" id="overlay"></div>
    <div id="app">
      <nav class="sidebar" id="sidebar">
        <div class="sidebar-header">
          <div class="sidebar-logo">${icon('coins', 18)}</div>
          <div>
            <div class="sidebar-brand-name">${esc(CONFIG.APP_NAME)}</div>
            <div class="sidebar-brand-sub">${esc(CONFIG.APP_SHORT)}</div>
          </div>
        </div>

        <div class="nav-section" id="nav">${navMarkup(me.role)}</div>

        <div class="sidebar-bottom">
          <button class="user-card" id="userCard">
            <div class="user-avatar">${esc(initials)}</div>
            <div style="flex:1;min-width:0">
              <div class="user-name">${esc(me.name)}</div>
              <div class="user-role">${me.role === 'owner' ? 'Ιδιοκτήτης' : 'Υπάλληλος'}</div>
            </div>
            ${icon('logout', 15)}
          </button>
        </div>
      </nav>

      <main class="main">
        <header class="topbar">
          <div style="display:flex;align-items:center;gap:12px;min-width:0">
            <button class="icon-btn burger" id="burger" aria-label="Μενού">${icon('menu')}</button>
            <div style="min-width:0">
              <div class="topbar-title" id="pageTitle">—</div>
              <div class="topbar-sub" id="pageSub"></div>
            </div>
          </div>
          <div class="topbar-actions">
            <div class="sync-pill" id="syncPill" data-state="local" title="Κατάσταση συγχρονισμού">
              <span class="sync-dot"></span><span id="syncText">Τοπικά</span>
            </div>
          </div>
        </header>
        <div class="content" id="content"></div>
      </main>
    </div>`;

  /* πλοήγηση */
  document.getElementById('nav').addEventListener('click', (e) => {
    const btn = e.target.closest('.nav-item');
    if (btn) location.hash = `#/${btn.dataset.key}`;
  });

  /* κινητό */
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('overlay');
  const closeSidebar = () => {
    sidebar.classList.remove('open');
    overlay.classList.remove('show');
  };
  document.getElementById('burger').addEventListener('click', () => {
    sidebar.classList.add('open');
    overlay.classList.add('show');
  });
  overlay.addEventListener('click', closeSidebar);
  window.addEventListener('hashchange', closeSidebar);

  /* αποσύνδεση */
  document.getElementById('userCard').addEventListener('click', async () => {
    const pending = await db.outbox.count();
    const question = pending
      ? `Υπάρχουν ${pending} εγγραφές που δεν έχουν σταλεί. Να γίνει αποσύνδεση;`
      : 'Να γίνει αποσύνδεση;';
    if (!confirm(question)) return;
    await auth.signOut();
    sync.stop();
    screenLogin();
  });

  /* ένδειξη συγχρονισμού */
  const pill = document.getElementById('syncPill');
  const text = document.getElementById('syncText');
  sync.onChange(({ state }) => {
    const labels = {
      local: 'Τοπικά', offline: 'Χωρίς δίκτυο', syncing: 'Συγχρονισμός…',
      synced: 'Ενημερωμένο', error: 'Σφάλμα'
    };
    pill.dataset.state = state;
    text.textContent = labels[state] || state;
  });
}

/* ================================================================== */
/* Δρομολόγηση                                                         */
/* ================================================================== */

async function route() {
  const me = auth.user();
  if (!me) return;

  const key = location.hash.replace(/^#\/?/, '') || homeFor(me.role);
  const item = findItem(key);

  // Άγνωστη ή απαγορευμένη διεύθυνση: γυρνάει στην αρχική του ρόλου.
  if (!item || !auth.can(item.roles)) {
    if (item && !auth.can(item.roles)) toast('Δεν έχεις πρόσβαση σε αυτή την οθόνη', 'err');
    location.hash = `#/${homeFor(me.role)}`;
    return;
  }

  const view = VIEWS[key] || placeholderView(key);
  document.getElementById('pageTitle').textContent = view.title;
  document.getElementById('pageSub').textContent = view.sub || '';

  document.querySelectorAll('.nav-item').forEach((b) => {
    b.classList.toggle('active', b.dataset.key === key);
    if (b.dataset.key === key) b.closest('.nav-grp')?.setAttribute('open', '');
  });

  const content = document.getElementById('content');
  content.innerHTML = '';
  repaintView = (await view.mount(content)) || null;
  content.scrollTop = 0;
}

/* ================================================================== */
/* Εκκίνηση                                                            */
/* ================================================================== */

async function startApp() {
  screenShell();
  window.addEventListener('hashchange', route);
  await route();
  await sync.start();
}

async function boot() {
  await db.open();

  if (await auth.needsSetup()) return screenSetup();

  const restored = await auth.restore();
  if (!restored) return screenLogin();

  await startApp();
}

/* Όταν ο συγχρονισμός φέρει αλλαγές, η ανοιχτή οθόνη ξαναζωγραφίζεται. */
window.addEventListener('data:changed', () => { repaintView?.(); });

window.addEventListener('error', (e) => {
  console.error(e.error || e.message);
});

boot().catch((err) => {
  console.error(err);
  root.innerHTML = `
    <div class="login-wrap"><div class="login-box">
      <h1>Η εφαρμογή δεν άνοιξε</h1>
      <p class="sub">${esc(err.message || 'Άγνωστο σφάλμα')}</p>
      <button class="btn btn-primary btn-full" onclick="location.reload()">Δοκίμασε ξανά</button>
    </div></div>`;
});

/* Service worker: κάνει την εφαρμογή να ανοίγει και χωρίς δίκτυο. */
if ('serviceWorker' in navigator && location.protocol === 'https:') {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('./sw.js').catch(() => { /* δεν εμποδίζει τη λειτουργία */ });
  });
}
