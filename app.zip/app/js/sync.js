/**
 * Συγχρονισμός.
 *
 * Στέλνει ό,τι περιμένει στην ουρά, μετά κατεβάζει ό,τι άλλαξε αλλού.
 * Σε σύγκρουση κερδίζει η εγγραφή με το μεγαλύτερο updated_at. Όταν οι δύο
 * χρόνοι είναι ίδιοι, αποφασίζει το device_id, ώστε όλες οι συσκευές να
 * καταλήγουν στο ίδιο αποτέλεσμα αντί να παλεύουν μεταξύ τους.
 */
import { CONFIG, isSyncConfigured } from './config.js';
import * as db from './db.js';
import * as api from './api.js';

const listeners = new Set();
let state = 'local';       // local | offline | syncing | synced | error
let lastError = null;
let lastSyncAt = null;
let timer = null;
let running = false;

export const getState = () => ({ state, lastError, lastSyncAt });

export function onChange(fn) {
  listeners.add(fn);
  fn(getState());
  return () => listeners.delete(fn);
}

function setState(next, error = null) {
  state = next;
  lastError = error;
  for (const fn of listeners) fn(getState());
}

/* ------------------------------------------------------------------ */
/* Αποστολή                                                            */
/* ------------------------------------------------------------------ */

async function pushPending() {
  const queued = await db.outbox.all();
  if (!queued.length) return 0;

  const byTable = new Map();
  for (const item of queued) {
    if (!byTable.has(item.table)) byTable.set(item.table, []);
    byTable.get(item.table).push(item);
  }

  let sent = 0;
  for (const [table, items] of byTable) {
    // Αν η ίδια εγγραφή άλλαξε πολλές φορές, στέλνουμε μόνο την τελευταία μορφή της.
    const latest = new Map();
    for (const item of items) latest.set(item.record.id, item.record);

    await api.push(table, [...latest.values()]);
    await db.outbox.remove(items.map((i) => i.key));
    sent += latest.size;
  }
  return sent;
}

/* ------------------------------------------------------------------ */
/* Λήψη                                                                */
/* ------------------------------------------------------------------ */

function remoteWins(remote, local) {
  if (!local) return true;
  if (remote.updated_at > local.updated_at) return true;
  if (remote.updated_at < local.updated_at) return false;
  return String(remote.device_id || '') > String(local.device_id || '');
}

async function pullTable(table) {
  const cursorKey = `cursor:${table}`;
  let cursor = await db.meta.get(cursorKey);
  let applied = 0;

  for (;;) {
    const rows = await api.pull(table, cursor, CONFIG.SYNC.pageSize);
    if (!rows || !rows.length) break;

    for (const remote of rows) {
      const local = await db.get(table, remote.id);
      if (remoteWins(remote, local)) {
        await db.putRemote(table, remote);
        applied++;
      }
      if (!cursor || remote.updated_at > cursor) cursor = remote.updated_at;
    }

    await db.meta.set(cursorKey, cursor);
    if (rows.length < CONFIG.SYNC.pageSize) break;
  }

  return applied;
}

/* ------------------------------------------------------------------ */
/* Εκτέλεση                                                            */
/* ------------------------------------------------------------------ */

export async function run({ silent = false } = {}) {
  if (!isSyncConfigured()) { setState('local'); return { skipped: 'not-configured' }; }
  if (!navigator.onLine)   { setState('offline'); return { skipped: 'offline' }; }
  if (!api.currentSession()) { setState('offline'); return { skipped: 'no-session' }; }
  if (running) return { skipped: 'busy' };

  running = true;
  if (!silent) setState('syncing');

  try {
    const sent = await pushPending();

    let received = 0;
    for (const table of Object.keys(db.TABLES)) {
      received += await pullTable(table);
    }

    lastSyncAt = new Date().toISOString();
    await db.meta.set('last_sync_at', lastSyncAt);
    setState('synced');

    if (sent || received) {
      window.dispatchEvent(new CustomEvent('data:changed', { detail: { sent, received } }));
    }
    return { sent, received };
  } catch (err) {
    setState('error', err.message || 'Ο συγχρονισμός απέτυχε');
    return { error: err };
  } finally {
    running = false;
  }
}

/* ------------------------------------------------------------------ */
/* Χρονοδιάγραμμα                                                      */
/* ------------------------------------------------------------------ */

export async function start() {
  lastSyncAt = await db.meta.get('last_sync_at');

  if (!isSyncConfigured()) { setState('local'); return; }

  const tick = () => run({ silent: true });

  window.addEventListener('online', () => { setState('syncing'); run(); });
  window.addEventListener('offline', () => setState('offline'));
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') tick();
  });

  clearInterval(timer);
  timer = setInterval(tick, CONFIG.SYNC.intervalMs);

  await run();
}

export function stop() {
  clearInterval(timer);
  timer = null;
}

/** Ξαναφέρνει τα πάντα από την αρχή. Για την περίπτωση που κάτι δεν κουμπώνει. */
export async function resetCursors() {
  for (const table of Object.keys(db.TABLES)) {
    await db.meta.remove(`cursor:${table}`);
  }
  return run();
}
