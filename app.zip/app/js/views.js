/**
 * Οθόνες.
 *
 * Κάθε οθόνη είναι ένα αντικείμενο με title, sub και mount(root).
 * Προσθήκη νέας: γράψε την εδώ και δώσε στο μενού το ίδιο key.
 */
import * as db from './db.js';
import * as sync from './sync.js';
import * as auth from './auth.js';
import { CONFIG, isSyncConfigured } from './config.js';
import { findItem } from './menu.js';
import {
  eur, num, esc, el, icon, toast, card, statCard, emptyState, placeholder,
  isoToday, dateGR, weekdayGR, monthLabel, relativeTime
} from './ui.js';

/* ================================================================== */
/* Ημερήσιο ταμείο — η οθόνη που αποδεικνύει ότι η αλυσίδα δουλεύει     */
/* ================================================================== */

const cafeDaily = {
  title: 'Ημερήσιο ταμείο',
  sub: 'Τζίρος, κάρτα και Ζ ανά ημέρα',

  async mount(root) {
    let month = isoToday().slice(0, 7);

    const paint = async () => {
      const rows = (await db.all('cafe_daily'))
        .filter((r) => r.date && r.date.startsWith(month))
        .sort((a, b) => b.date.localeCompare(a.date));

      const sum = (field) => rows.reduce((t, r) => t + (Number(r[field]) || 0), 0);
      const today = rows.find((r) => r.date === isoToday());

      root.innerHTML = `
        <div class="stats-grid">
          ${statCard('Τζίρος μήνα', eur(sum('turnover')), `${rows.length} ημέρες`, 'c-blue')}
          ${statCard('Κάρτα', eur(sum('card')), '', 'c-purple')}
          ${statCard('Ζ', eur(sum('z_reading')), '', 'c-green')}
          ${statCard('Σήμερα', today ? eur(today.turnover) : '—',
                     today ? 'καταχωρήθηκε' : 'εκκρεμεί', today ? 'c-green' : 'c-orange')}
        </div>

        ${card('Καταχώρηση ημέρας', `
          <form id="dayForm" autocomplete="off">
            <div class="field-row">
              <div class="field">
                <label for="fDate">Ημερομηνία</label>
                <input type="date" id="fDate" value="${isoToday()}" max="${isoToday()}" required>
              </div>
              <div class="field">
                <label for="fTurnover">Τζίρος</label>
                <input type="number" id="fTurnover" step="0.01" min="0" placeholder="0,00" required>
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label for="fCard">Κάρτα</label>
                <input type="number" id="fCard" step="0.01" min="0" placeholder="0,00" required>
              </div>
              <div class="field">
                <label for="fZ">Ζ</label>
                <input type="number" id="fZ" step="0.01" min="0" placeholder="0,00" required>
              </div>
            </div>
            <div class="field">
              <label for="fNote">Σημείωση</label>
              <input type="text" id="fNote" placeholder="Προαιρετικά">
            </div>
            <button type="submit" class="btn btn-primary">${icon('save')} Αποθήκευση ημέρας</button>
            <p class="hint" id="dayHint" style="margin-top:8px;font-size:.7rem;color:var(--text3)"></p>
          </form>`, { sub: 'Αν η ημέρα υπάρχει ήδη, η καταχώρηση την ενημερώνει' })}

        ${card(monthLabel(`${month}-01`), `
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Ημερομηνία</th><th>Ημέρα</th>
                  <th class="num">Τζίρος</th><th class="num">Κάρτα</th><th class="num">Ζ</th>
                  <th>Σημείωση</th><th></th>
                </tr>
              </thead>
              <tbody>
                ${rows.length ? rows.map((r) => `
                  <tr>
                    <td>${dateGR(r.date)}</td>
                    <td style="color:var(--text3)">${weekdayGR(r.date)}</td>
                    <td class="num">${num(r.turnover)}</td>
                    <td class="num">${num(r.card)}</td>
                    <td class="num">${num(r.z_reading)}</td>
                    <td style="color:var(--text3)">${esc(r.note || '')}</td>
                    <td><button class="btn btn-sm" data-edit="${esc(r.id)}">Άνοιγμα</button></td>
                  </tr>`).join('') : `
                  <tr><td colspan="7">${emptyState('Καμία καταχώρηση αυτόν τον μήνα',
                      'Συμπλήρωσε την πρώτη ημέρα από τη φόρμα πιο πάνω.')}</td></tr>`}
              </tbody>
              ${rows.length ? `
              <tfoot>
                <tr style="font-weight:700;background:var(--bg4)">
                  <td colspan="2">Σύνολο</td>
                  <td class="num">${num(sum('turnover'))}</td>
                  <td class="num">${num(sum('card'))}</td>
                  <td class="num">${num(sum('z_reading'))}</td>
                  <td colspan="2"></td>
                </tr>
              </tfoot>` : ''}
            </table>
          </div>`, {
            actions: `
              <button class="btn btn-sm" id="prevMonth">← Προηγούμενος</button>
              <button class="btn btn-sm" id="nextMonth">Επόμενος →</button>`
          })}
      `;

      /* ---- γεγονότα ---- */

      const form = root.querySelector('#dayForm');
      const hint = root.querySelector('#dayHint');
      const fDate = root.querySelector('#fDate');

      const showExisting = async () => {
        const match = (await db.all('cafe_daily')).find((r) => r.date === fDate.value);
        if (match) {
          root.querySelector('#fTurnover').value = match.turnover ?? '';
          root.querySelector('#fCard').value = match.card ?? '';
          root.querySelector('#fZ').value = match.z_reading ?? '';
          root.querySelector('#fNote').value = match.note ?? '';
          hint.textContent = 'Η ημέρα έχει ήδη καταχωρηθεί. Η αποθήκευση θα την ενημερώσει.';
        } else {
          hint.textContent = '';
        }
      };

      fDate.addEventListener('change', showExisting);
      await showExisting();

      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const date = fDate.value;
        const existing = (await db.all('cafe_daily')).find((r) => r.date === date);

        await db.put('cafe_daily', {
          id: existing?.id,
          date,
          turnover: Number(root.querySelector('#fTurnover').value) || 0,
          card: Number(root.querySelector('#fCard').value) || 0,
          z_reading: Number(root.querySelector('#fZ').value) || 0,
          note: root.querySelector('#fNote').value.trim() || null
        }, { user_id: auth.user()?.id });

        toast(existing ? 'Η ημέρα ενημερώθηκε' : 'Η ημέρα αποθηκεύτηκε', 'ok');
        sync.run({ silent: true });
        month = date.slice(0, 7);
        await paint();
      });

      root.querySelectorAll('[data-edit]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const row = await db.get('cafe_daily', btn.dataset.edit);
          if (!row) return;
          fDate.value = row.date;
          await showExisting();
          root.querySelector('#dayForm').scrollIntoView({ block: 'center' });
        });
      });

      const shift = (delta) => {
        const [y, m] = month.split('-').map(Number);
        const d = new Date(y, m - 1 + delta, 1);
        month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        paint();
      };
      root.querySelector('#prevMonth')?.addEventListener('click', () => shift(-1));
      root.querySelector('#nextMonth')?.addEventListener('click', () => shift(1));
    };

    await paint();
    return paint;
  }
};

/* ================================================================== */
/* Πίνακας ελέγχου                                                     */
/* ================================================================== */

const dashboard = {
  title: 'Πίνακας ελέγχου',
  sub: 'Συνολική εικόνα',

  async mount(root) {
    const days = await db.all('cafe_daily');
    const month = isoToday().slice(0, 7);
    const thisMonth = days.filter((d) => d.date?.startsWith(month));
    const turnover = thisMonth.reduce((t, d) => t + (Number(d.turnover) || 0), 0);
    const lastSync = await db.meta.get('last_sync_at');
    const pending = await db.outbox.count();

    root.innerHTML = `
      <div class="stats-grid">
        ${statCard('Τζίρος καφετέριας', eur(turnover), monthLabel(`${month}-01`), 'c-blue')}
        ${statCard('Ημέρες καταχωρημένες', String(thisMonth.length), 'αυτόν τον μήνα', 'c-green')}
        ${statCard('Εκκρεμούν αποστολή', String(pending), pending ? 'θα φύγουν με το δίκτυο' : 'όλα εστάλησαν', pending ? 'c-orange' : 'c-green')}
        ${statCard('Τελευταίος συγχρονισμός', relativeTime(lastSync), isSyncConfigured() ? '' : 'τοπική λειτουργία', 'c-purple')}
      </div>

      ${card('Πού βρισκόμαστε', `
        <p style="font-size:.82rem;color:var(--text2);line-height:1.7">
          Ο σκελετός, η είσοδος με ρόλους και ο συγχρονισμός είναι στη θέση τους.
          Το ημερήσιο ταμείο δουλεύει κανονικά και αποθηκεύει τοπικά, ακόμα και χωρίς δίκτυο.
          Οι υπόλοιπες οθόνες ανοίγουν και δείχνουν σε ποια φάση έρχονται.
        </p>`)}
    `;
  }
};

/* ================================================================== */
/* Σύστημα                                                             */
/* ================================================================== */

const systemSync = {
  title: 'Συγχρονισμός',
  sub: 'Κατάσταση και χειροκίνητος έλεγχος',

  async mount(root) {
    const paint = async () => {
      const { state, lastError, lastSyncAt } = sync.getState();
      const pending = await db.outbox.count();
      const labels = {
        local: 'Τοπική λειτουργία', offline: 'Χωρίς δίκτυο', syncing: 'Σε εξέλιξη',
        synced: 'Ενημερωμένο', error: 'Σφάλμα'
      };

      root.innerHTML = `
        ${!isSyncConfigured() ? `
          <div class="msg warn">
            Ο συγχρονισμός δεν έχει ρυθμιστεί. Τα δεδομένα μένουν σε αυτή τη συσκευή.
            Συμπλήρωσε <strong>url</strong> και <strong>anonKey</strong> στο αρχείο
            <code>js/config.js</code> και κάνε επαναφόρτωση.
          </div>` : ''}

        <div class="stats-grid">
          ${statCard('Κατάσταση', labels[state] || state, lastError || '', state === 'error' ? 'c-orange' : 'c-green')}
          ${statCard('Εκκρεμείς εγγραφές', String(pending), 'στην ουρά αποστολής', 'c-blue')}
          ${statCard('Τελευταία επιτυχία', relativeTime(lastSyncAt), '', 'c-purple')}
        </div>

        ${card('Ενέργειες', `
          <div class="topbar-actions" style="flex-wrap:wrap">
            <button class="btn btn-primary" id="runNow" ${isSyncConfigured() ? '' : 'disabled'}>
              ${icon('refresh')} Συγχρονισμός τώρα
            </button>
            <button class="btn" id="fullPull" ${isSyncConfigured() ? '' : 'disabled'}>
              Πλήρες ξανακατέβασμα
            </button>
          </div>
          <p style="font-size:.72rem;color:var(--text3);margin-top:10px">
            Το πλήρες ξανακατέβασμα φέρνει όλες τις εγγραφές από την αρχή. Χρήσιμο μόνο
            αν κάτι δεν συμφωνεί ανάμεσα σε δύο συσκευές.
          </p>`)}
      `;

      root.querySelector('#runNow')?.addEventListener('click', async (e) => {
        e.target.disabled = true;
        const result = await sync.run();
        toast(result.error ? 'Ο συγχρονισμός απέτυχε' : 'Ολοκληρώθηκε', result.error ? 'err' : 'ok');
        await paint();
      });

      root.querySelector('#fullPull')?.addEventListener('click', async (e) => {
        e.target.disabled = true;
        await sync.resetCursors();
        toast('Τα δεδομένα ξανακατέβηκαν', 'ok');
        await paint();
      });
    };

    await paint();
    return paint;
  }
};

const systemUsers = {
  title: 'Χρήστες & δικαιώματα',
  sub: 'Ποιος μπαίνει και τι βλέπει',

  async mount(root) {
    const profiles = await db.all('profiles');
    const me = auth.user();

    root.innerHTML = `
      ${card('Λογαριασμοί', `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Όνομα</th><th>Email</th><th>Ρόλος</th><th>Κατάσταση</th></tr></thead>
            <tbody>
              ${profiles.length ? profiles.map((p) => `
                <tr>
                  <td>${esc(p.name)}${p.id === me?.id ? ' <span style="color:var(--text3)">(εσύ)</span>' : ''}</td>
                  <td>${esc(p.email || '—')}</td>
                  <td>${p.role === 'owner' ? 'Ιδιοκτήτης' : 'Υπάλληλος'}</td>
                  <td>${p.active === false ? 'Ανενεργός' : 'Ενεργός'}</td>
                </tr>`).join('') : `
                <tr><td colspan="4">${emptyState('Κανένας άλλος λογαριασμός',
                    'Οι λογαριασμοί υπαλλήλων δημιουργούνται από τον Supabase.')}</td></tr>`}
            </tbody>
          </table>
        </div>`)}

      ${card('Τι βλέπει ο υπάλληλος', `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Οθόνη</th><th>Ιδιοκτήτης</th><th>Υπάλληλος</th></tr></thead>
            <tbody>
              <tr><td>Ημερήσιο ταμείο</td><td>Πλήρης</td><td>Δεν εμφανίζεται</td></tr>
              <tr><td>Τιμολόγια προμηθευτών</td><td>Πλήρης</td><td>Καταχώρηση, χωρίς έγκριση</td></tr>
              <tr><td>Λίστες παραγγελίας</td><td>Πλήρης</td><td>Προσθήκη ειδών</td></tr>
              <tr><td>Πρώτες ύλες</td><td>Πλήρης</td><td>Μόνο ανάγνωση</td></tr>
              <tr><td>Όλα τα υπόλοιπα</td><td>Πλήρης</td><td>Δεν εμφανίζονται</td></tr>
            </tbody>
          </table>
        </div>`, { sub: 'Ο περιορισμός επιβάλλεται και από τον server, όχι μόνο από το μενού' })}
    `;
  }
};

const systemSettings = {
  title: 'Ρυθμίσεις',
  sub: 'Συσκευή και τοπικά δεδομένα',

  async mount(root) {
    const counts = await db.stats();
    const device = await db.deviceId();
    const rows = Object.entries(counts).filter(([, n]) => n > 0);

    root.innerHTML = `
      ${card('Αυτή η συσκευή', `
        <div class="field"><label>Αναγνωριστικό συσκευής</label>
          <input value="${esc(device)}" readonly></div>
        <div class="field"><label>Συγχρονισμός</label>
          <input value="${isSyncConfigured() ? CONFIG.SUPABASE.url : 'Δεν έχει ρυθμιστεί'}" readonly></div>`)}

      ${card('Τοπικά δεδομένα', `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Πίνακας</th><th class="num">Εγγραφές</th></tr></thead>
            <tbody>
              ${rows.length ? rows.map(([t, n]) => `
                <tr><td>${esc(t)}</td><td class="num">${n}</td></tr>`).join('') : `
                <tr><td colspan="2">${emptyState('Άδεια βάση', 'Δεν έχει καταχωρηθεί τίποτα ακόμα.')}</td></tr>`}
            </tbody>
          </table>
        </div>`)}

      ${card('Καθαρισμός', `
        <p style="font-size:.78rem;color:var(--text2);margin-bottom:12px">
          Σβήνει τα δεδομένα από αυτή τη συσκευή. Ό,τι έχει ήδη συγχρονιστεί ξανακατεβαίνει.
          Ό,τι δεν πρόλαβε να φύγει, χάνεται.
        </p>
        <button class="btn btn-danger" id="wipe">Καθαρισμός συσκευής</button>`)}
    `;

    root.querySelector('#wipe')?.addEventListener('click', async () => {
      const pending = await db.outbox.count();
      const warning = pending
        ? `Υπάρχουν ${pending} εγγραφές που δεν έχουν σταλεί και θα χαθούν. Συνέχεια;`
        : 'Να σβηστούν τα τοπικά δεδομένα;';
      if (!confirm(warning)) return;
      await db.wipe();
      toast('Η συσκευή καθαρίστηκε', 'ok');
      location.reload();
    });
  }
};

/* ================================================================== */
/* Μητρώο                                                              */
/* ================================================================== */

export const VIEWS = {
  dashboard,
  'cafe/daily': cafeDaily,
  'system/sync': systemSync,
  'system/users': systemUsers,
  'system/settings': systemSettings
};

/** Οθόνη αναμονής για ό,τι δεν έχει έρθει ακόμα. */
export function placeholderView(key) {
  const item = findItem(key);
  const descriptions = {
    2: 'Έρχεται μαζί με τα έξοδα και τις κατηγορίες τους.',
    3: 'Έρχεται μαζί με τους προμηθευτές και την ανάγνωση τιμολογίων.',
    4: 'Έρχεται μαζί με τις λίστες παραγγελίας.',
    5: 'Έρχεται μαζί με τις συνταγές και το food cost.',
    6: 'Έρχεται με τη μεταφορά των καταλυμάτων.',
    7: 'Έρχεται με τις αναφορές.'
  };

  return {
    title: item?.label || 'Οθόνη',
    sub: 'Δεν έχει υλοποιηθεί ακόμα',
    async mount(root) {
      root.innerHTML = placeholder(
        item?.label || 'Οθόνη',
        descriptions[item?.phase] || 'Θα προστεθεί σε επόμενη φάση.',
        item?.phase ?? '—'
      );
    }
  };
}
