/**
 * Πελάτης Supabase μέσω REST, χωρίς εξωτερική βιβλιοθήκη.
 *
 * Ο λόγος που δεν φορτώνουμε το επίσημο SDK από CDN: η εφαρμογή πρέπει να
 * ανοίγει και χωρίς δίκτυο. Ό,τι έρχεται από τρίτον είναι ένα ακόμα σημείο
 * που μπορεί να λείπει τη λάθος στιγμή.
 */
import { CONFIG, isSyncConfigured } from './config.js';
import * as db from './db.js';

const base = () => CONFIG.SUPABASE.url.replace(/\/$/, '');

export class ApiError extends Error {
  constructor(message, status, body) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.body = body;
  }
}

/* ------------------------------------------------------------------ */
/* Συνεδρία                                                            */
/* ------------------------------------------------------------------ */

let session = null;   // { access_token, refresh_token, expires_at, user }

export async function loadSession() {
  session = await db.meta.get('session');
  return session;
}

export function currentSession() {
  return session;
}

async function saveSession(next) {
  session = next;
  await db.meta.set('session', next);
  return next;
}

export async function clearSession() {
  session = null;
  await db.meta.remove('session');
}

function expiresAt(expiresIn) {
  return Date.now() + (Number(expiresIn) || 3600) * 1000;
}

/** Ανανεώνει το token όταν του μένουν λιγότερα από 60 δευτερόλεπτα. */
async function freshToken() {
  if (!session) throw new ApiError('Δεν υπάρχει συνεδρία', 401);
  if (session.expires_at - Date.now() > 60_000) return session.access_token;

  const res = await fetch(`${base()}/auth/v1/token?grant_type=refresh_token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: CONFIG.SUPABASE.anonKey },
    body: JSON.stringify({ refresh_token: session.refresh_token })
  });

  if (!res.ok) {
    await clearSession();
    throw new ApiError('Η συνεδρία έληξε', res.status);
  }

  const data = await res.json();
  await saveSession({
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: expiresAt(data.expires_in),
    user: data.user || session.user
  });
  return session.access_token;
}

export async function signIn(email, password) {
  const res = await fetch(`${base()}/auth/v1/token?grant_type=password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', apikey: CONFIG.SUPABASE.anonKey },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new ApiError(
      data.error_description || data.msg || 'Λάθος email ή κωδικός',
      res.status,
      data
    );
  }

  return saveSession({
    access_token: data.access_token,
    refresh_token: data.refresh_token,
    expires_at: expiresAt(data.expires_in),
    user: data.user
  });
}

export async function signOut() {
  try {
    if (session) {
      await fetch(`${base()}/auth/v1/logout`, {
        method: 'POST',
        headers: {
          apikey: CONFIG.SUPABASE.anonKey,
          Authorization: `Bearer ${session.access_token}`
        }
      });
    }
  } catch { /* η τοπική αποσύνδεση προχωράει έτσι κι αλλιώς */ }
  await clearSession();
}

/* ------------------------------------------------------------------ */
/* Δεδομένα                                                            */
/* ------------------------------------------------------------------ */

async function request(path, options = {}) {
  if (!isSyncConfigured()) throw new ApiError('Ο συγχρονισμός δεν έχει ρυθμιστεί', 0);

  const token = await freshToken();
  const res = await fetch(`${base()}/rest/v1/${path}`, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      apikey: CONFIG.SUPABASE.anonKey,
      Authorization: `Bearer ${token}`,
      ...(options.headers || {})
    }
  });

  if (!res.ok) {
    const body = await res.text();
    throw new ApiError(`Το αίτημα απέτυχε (${res.status})`, res.status, body);
  }

  if (res.status === 204) return null;
  const text = await res.text();
  return text ? JSON.parse(text) : null;
}

/** Κατεβάζει ό,τι άλλαξε μετά από ένα χρονικό σημείο. */
export function pull(table, since, limit) {
  const params = new URLSearchParams({
    select: '*',
    order: 'updated_at.asc',
    limit: String(limit)
  });
  if (since) params.append('updated_at', `gt.${since}`);
  return request(`${table}?${params}`);
}

/** Ανεβάζει εγγραφές. Ό,τι υπάρχει ήδη ενημερώνεται. */
export function push(table, records) {
  return request(table, {
    method: 'POST',
    headers: { Prefer: 'resolution=merge-duplicates,return=minimal' },
    body: JSON.stringify(records)
  });
}

export function selectOne(table, column, value) {
  const params = new URLSearchParams({ select: '*', [column]: `eq.${value}`, limit: '1' });
  return request(`${table}?${params}`).then((rows) => (rows && rows[0]) || null);
}
