/**
 * Είσοδος, ρόλοι, και σύνδεση χωρίς δίκτυο.
 *
 * Δύο περιπτώσεις:
 *
 * 1. Ρυθμισμένος συγχρονισμός → η είσοδος γίνεται στον Supabase. Μετά από
 *    πετυχημένη σύνδεση κρατάμε τοπικά έναν αποτυπωμένο κωδικό (PBKDF2), ώστε
 *    ο ίδιος χρήστης να μπορεί να μπει και όταν δεν υπάρχει ίντερνετ.
 *
 * 2. Χωρίς συγχρονισμό → τοπικός λογαριασμός ιδιοκτήτη, που φτιάχνεται στο
 *    πρώτο άνοιγμα. Χρησιμεύει μέχρι να στηθεί ο server.
 *
 * Ο τοπικός κωδικός δεν αποθηκεύεται ποτέ σε καθαρή μορφή.
 */
import { isSyncConfigured } from './config.js';
import * as db from './db.js';
import * as api from './api.js';

const OFFLINE_GRACE_DAYS = 30;

let current = null;   // { id, email, name, role }

export const ROLES = { OWNER: 'owner', STAFF: 'staff' };

export const user = () => current;
export const isOwner = () => current?.role === ROLES.OWNER;
export const can = (roles) => !roles || !roles.length || roles.includes(current?.role);

/* ------------------------------------------------------------------ */
/* Κρυπτογράφηση κωδικού                                               */
/* ------------------------------------------------------------------ */

const enc = new TextEncoder();

function toHex(buffer) {
  return [...new Uint8Array(buffer)].map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function hashPassword(password, saltHex) {
  const salt = saltHex
    ? Uint8Array.from(saltHex.match(/.{2}/g).map((h) => parseInt(h, 16)))
    : crypto.getRandomValues(new Uint8Array(16));

  const key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const bits = await crypto.subtle.deriveBits(
    { name: 'PBKDF2', salt, iterations: 150_000, hash: 'SHA-256' },
    key,
    256
  );

  return { hash: toHex(bits), salt: toHex(salt) };
}

/** Σύγκριση σταθερού χρόνου, ώστε να μην διαρρέει πληροφορία από τη διάρκεια. */
function sameHash(a, b) {
  if (!a || !b || a.length !== b.length) return false;
  let diff = 0;
  for (let i = 0; i < a.length; i++) diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}

/* ------------------------------------------------------------------ */
/* Κατάσταση                                                           */
/* ------------------------------------------------------------------ */

/** Υπάρχει τοπικός λογαριασμός; Αν όχι, δείχνουμε την οθόνη πρώτης ρύθμισης. */
export async function needsSetup() {
  if (isSyncConfigured()) return false;
  return !(await db.meta.get('local_account'));
}

/** Επαναφορά συνεδρίας στο άνοιγμα της εφαρμογής. */
export async function restore() {
  const saved = await db.meta.get('current_user');
  if (!saved) return null;

  if (isSyncConfigured()) {
    await api.loadSession();
    const session = api.currentSession();
    const stale = !session || Date.now() - (saved.verified_at || 0) > OFFLINE_GRACE_DAYS * 864e5;
    if (stale) return null;
  }

  current = saved.user;
  return current;
}

/* ------------------------------------------------------------------ */
/* Πρώτη ρύθμιση                                                       */
/* ------------------------------------------------------------------ */

export async function createLocalOwner({ name, email, password }) {
  if (password.length < 8) throw new Error('Ο κωδικός θέλει τουλάχιστον 8 χαρακτήρες');

  const { hash, salt } = await hashPassword(password);
  const account = {
    id: db.uuid(),
    email: email.trim().toLowerCase(),
    name: name.trim(),
    role: ROLES.OWNER,
    hash,
    salt
  };

  await db.meta.set('local_account', account);
  await db.put('profiles', {
    id: account.id, name: account.name, email: account.email,
    role: account.role, active: true
  }, { user_id: account.id });

  return signInLocal(account.email, password);
}

/* ------------------------------------------------------------------ */
/* Είσοδος                                                             */
/* ------------------------------------------------------------------ */

async function remember(profile) {
  current = profile;
  await db.meta.set('current_user', { user: profile, verified_at: Date.now() });
  return profile;
}

async function signInLocal(email, password) {
  const account = await db.meta.get('local_account');
  if (!account || account.email !== email.trim().toLowerCase()) {
    throw new Error('Λάθος email ή κωδικός');
  }

  const { hash } = await hashPassword(password, account.salt);
  if (!sameHash(hash, account.hash)) throw new Error('Λάθος email ή κωδικός');

  return remember({
    id: account.id, email: account.email, name: account.name, role: account.role
  });
}

/** Είσοδος με τα στοιχεία που κρατήθηκαν από προηγούμενη online σύνδεση. */
async function signInOffline(email, password) {
  const cached = await db.meta.get(`offline:${email.trim().toLowerCase()}`);
  if (!cached) {
    throw new Error('Χωρίς ίντερνετ μπορούν να μπουν μόνο όσοι έχουν ξανασυνδεθεί σε αυτή τη συσκευή');
  }
  if (Date.now() - cached.saved_at > OFFLINE_GRACE_DAYS * 864e5) {
    throw new Error('Πέρασε πολύς καιρός χωρίς σύνδεση. Χρειάζεται ίντερνετ για να μπεις');
  }

  const { hash } = await hashPassword(password, cached.salt);
  if (!sameHash(hash, cached.hash)) throw new Error('Λάθος email ή κωδικός');

  return remember(cached.profile);
}

export async function signIn(email, password) {
  if (!isSyncConfigured()) return signInLocal(email, password);
  if (!navigator.onLine) return signInOffline(email, password);

  let session;
  try {
    session = await api.signIn(email, password);
  } catch (err) {
    // Δίκτυο που πέφτει στη μέση δεν πρέπει να κλειδώνει έξω κάποιον που ξέρει τον κωδικό του.
    if (err.status === 0 || err.name === 'TypeError') return signInOffline(email, password);
    throw err;
  }

  const profile = await api.selectOne('profiles', 'id', session.user.id);
  if (!profile) throw new Error('Ο λογαριασμός δεν έχει προφίλ. Επικοινώνησε με τον διαχειριστή');
  if (profile.active === false) throw new Error('Ο λογαριασμός είναι ανενεργός');

  const clean = {
    id: profile.id, email: session.user.email, name: profile.name, role: profile.role
  };

  const { hash, salt } = await hashPassword(password);
  await db.meta.set(`offline:${clean.email}`, { profile: clean, hash, salt, saved_at: Date.now() });

  return remember(clean);
}

export async function signOut({ forget = false } = {}) {
  if (isSyncConfigured()) await api.signOut();
  await db.meta.remove('current_user');
  current = null;
  // Τα δεδομένα μένουν στη συσκευή ώστε ο επόμενος συγχρονισμός να μην ξεκινά από το μηδέν.
  if (forget) await db.wipe();
}
