/**
 * Κοινά βοηθήματα διεπαφής: μορφοποίηση, εικονίδια, μηνύματα, δόμηση HTML.
 */
import { CONFIG } from './config.js';

/* ------------------------------------------------------------------ */
/* Μορφοποίηση                                                         */
/* ------------------------------------------------------------------ */

const money = new Intl.NumberFormat(CONFIG.LOCALE, {
  style: 'currency', currency: CONFIG.CURRENCY,
  minimumFractionDigits: 2, maximumFractionDigits: 2
});

export const eur = (n) => money.format(Number(n) || 0);
export const num = (n, d = 2) =>
  new Intl.NumberFormat(CONFIG.LOCALE, { minimumFractionDigits: d, maximumFractionDigits: d })
    .format(Number(n) || 0);

export function isoToday() {
  const now = new Date();
  const local = new Date(now.getTime() - now.getTimezoneOffset() * 60000);
  return local.toISOString().slice(0, 10);
}

export function dateGR(iso) {
  if (!iso) return '—';
  const [y, m, d] = iso.slice(0, 10).split('-');
  return `${d}/${m}/${y}`;
}

export function weekdayGR(iso) {
  if (!iso) return '';
  const days = ['Κυριακή', 'Δευτέρα', 'Τρίτη', 'Τετάρτη', 'Πέμπτη', 'Παρασκευή', 'Σάββατο'];
  return days[new Date(`${iso}T12:00:00`).getDay()];
}

export function monthLabel(iso) {
  const months = ['Ιανουάριος','Φεβρουάριος','Μάρτιος','Απρίλιος','Μάιος','Ιούνιος',
                  'Ιούλιος','Αύγουστος','Σεπτέμβριος','Οκτώβριος','Νοέμβριος','Δεκέμβριος'];
  const [y, m] = iso.slice(0, 7).split('-');
  return `${months[Number(m) - 1]} ${y}`;
}

export function relativeTime(iso) {
  if (!iso) return 'ποτέ';
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.round(diff / 60000);
  if (mins < 1) return 'μόλις τώρα';
  if (mins < 60) return `πριν ${mins} λεπτά`;
  const hours = Math.round(mins / 60);
  if (hours < 24) return `πριν ${hours} ${hours === 1 ? 'ώρα' : 'ώρες'}`;
  const days = Math.round(hours / 24);
  return `πριν ${days} ${days === 1 ? 'ημέρα' : 'ημέρες'}`;
}

/* ------------------------------------------------------------------ */
/* HTML                                                                */
/* ------------------------------------------------------------------ */

/** Καθαρίζει κείμενο πριν μπει σε HTML. Κάθε τιμή χρήστη περνάει από εδώ. */
export function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

export function el(html) {
  const t = document.createElement('template');
  t.innerHTML = html.trim();
  return t.content.firstElementChild;
}

export const icon = (name, size = 16) => {
  const paths = {
    home:     '<path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>',
    calendar: '<rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/>',
    bell:     '<path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.7 21a2 2 0 01-3.4 0"/>',
    cash:     '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="2.5"/>',
    truck:    '<path d="M3 6h11v9H3z"/><path d="M14 9h4l3 3v3h-7z"/><circle cx="7" cy="18" r="1.6"/><circle cx="17" cy="18" r="1.6"/>',
    file:     '<path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/><polyline points="14 2 14 8 20 8"/>',
    list:     '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
    box:      '<path d="M21 8l-9-5-9 5v8l9 5 9-5z"/><polyline points="3 8 12 13 21 8"/>',
    chart:    '<line x1="4" y1="20" x2="4" y2="10"/><line x1="10" y1="20" x2="10" y2="4"/><line x1="16" y1="20" x2="16" y2="14"/><line x1="21" y1="20" x2="3" y2="20"/>',
    coins:    '<ellipse cx="12" cy="6" rx="8" ry="3"/><path d="M4 6v6c0 1.7 3.6 3 8 3s8-1.3 8-3V6"/><path d="M4 12v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6"/>',
    users:    '<path d="M16 21v-2a4 4 0 00-4-4H6a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 00-3-3.87"/>',
    bed:      '<path d="M3 18v-6h18v6"/><path d="M3 12V7"/><path d="M21 18v2"/><path d="M3 18v2"/><circle cx="8" cy="10" r="2"/>',
    video:    '<polygon points="23 7 16 12 23 17"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    settings: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 11-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 11-4 0v-.09A1.65 1.65 0 008 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 11-2.83-2.83l.06-.06A1.65 1.65 0 004.6 15a1.65 1.65 0 00-1.51-1H3a2 2 0 110-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 112.83-2.83l.06.06A1.65 1.65 0 009 4.6h.09A1.65 1.65 0 0010 3.09V3a2 2 0 114 0v.09A1.65 1.65 0 0015 4.6a1.65 1.65 0 001.82-.33l.06-.06a2 2 0 112.83 2.83l-.06.06A1.65 1.65 0 0019.4 9v.09a1.65 1.65 0 001.51 1H21a2 2 0 110 4h-.09a1.65 1.65 0 00-1.51 1z"/>',
    save:     '<path d="M19 21H5a2 2 0 01-2-2V5a2 2 0 012-2h11l5 5v11a2 2 0 01-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/>',
    logout:   '<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>',
    menu:     '<line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/>',
    refresh:  '<polyline points="23 4 23 10 17 10"/><path d="M20.5 15a9 9 0 11-2.1-9.4L23 10"/>',
    lock:     '<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0110 0v4"/>'
  };

  return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"
    stroke-linecap="round" stroke-linejoin="round" width="${size}" height="${size}"
    aria-hidden="true">${paths[name] || paths.box}</svg>`;
};

/* ------------------------------------------------------------------ */
/* Μηνύματα                                                            */
/* ------------------------------------------------------------------ */

export function toast(message, kind = '') {
  let host = document.getElementById('toasts');
  if (!host) {
    host = el('<div id="toasts"></div>');
    document.body.appendChild(host);
  }

  const node = el(`<div class="toast ${kind}" role="status">${esc(message)}</div>`);
  host.appendChild(node);

  setTimeout(() => {
    node.style.transition = 'opacity .3s';
    node.style.opacity = '0';
    setTimeout(() => node.remove(), 300);
  }, 3200);
}

/* ------------------------------------------------------------------ */
/* Δομικά κομμάτια                                                     */
/* ------------------------------------------------------------------ */

export const statCard = (label, value, sub = '', color = 'c-blue') => `
  <div class="stat-card ${color}">
    <div class="stat-label">${esc(label)}</div>
    <div class="stat-value">${esc(value)}</div>
    ${sub ? `<div class="stat-sub">${esc(sub)}</div>` : ''}
  </div>`;

export const card = (title, body, { sub = '', actions = '' } = {}) => `
  <section class="card">
    <div class="card-header">
      <div>
        <div class="card-title">${esc(title)}</div>
        ${sub ? `<div class="card-sub">${esc(sub)}</div>` : ''}
      </div>
      ${actions ? `<div class="topbar-actions">${actions}</div>` : ''}
    </div>
    ${body}
  </section>`;

export const emptyState = (title, hint) => `
  <div class="empty"><strong>${esc(title)}</strong>${esc(hint)}</div>`;

export const placeholder = (title, description, phase) => `
  <div class="placeholder">
    <h3>${esc(title)}</h3>
    <p>${esc(description)}</p>
    <span class="phase">Φάση ${esc(phase)}</span>
  </div>`;

/* ------------------------------------------------------------------ */
/* Διάλογος                                                            */
/* ------------------------------------------------------------------ */

/**
 * Ανοίγει διάλογο και επιστρέφει ό,τι γυρίσει το onSave, ή null στην άκυρωση.
 * Το onSave παίρνει το στοιχείο της φόρμας. Αν πετάξει σφάλμα, το μήνυμα
 * εμφανίζεται μέσα στον διάλογο και ο διάλογος μένει ανοιχτός.
 */
export function modal({ title, body, saveLabel = 'Αποθήκευση', cancelLabel = 'Άκυρο', onSave, extra = '' }) {
  return new Promise((resolve) => {
    const dlg = el(`
      <dialog class="modal">
        <form method="dialog">
          <div class="modal-head">
            <div class="modal-title">${esc(title)}</div>
          </div>
          <div class="modal-body">
            <div id="modalError"></div>
            ${body}
          </div>
          <div class="modal-foot">
            ${extra}
            <button type="button" class="btn" data-cancel>${esc(cancelLabel)}</button>
            <button type="button" class="btn btn-primary" data-save>${esc(saveLabel)}</button>
          </div>
        </form>
      </dialog>`);

    document.body.appendChild(dlg);
    dlg.showModal();

    const close = (value) => {
      dlg.close();
      dlg.remove();
      resolve(value);
    };

    dlg.querySelector('[data-cancel]').addEventListener('click', () => close(null));
    dlg.addEventListener('cancel', (e) => { e.preventDefault(); close(null); });

    dlg.querySelector('[data-save]').addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      btn.disabled = true;
      try {
        const result = await onSave(dlg);
        close(result === undefined ? true : result);
      } catch (err) {
        dlg.querySelector('#modalError').innerHTML =
          `<div class="msg error">${esc(err.message)}</div>`;
        btn.disabled = false;
      }
    });

    dlg.querySelector('input,select,textarea')?.focus();
  });
}

export async function confirmDialog(title, message, { danger = true } = {}) {
  const answer = await modal({
    title,
    body: `<p style="font-size:.85rem;color:var(--text2);line-height:1.6">${esc(message)}</p>`,
    saveLabel: danger ? 'Διαγραφή' : 'Συνέχεια',
    onSave: () => true
  });
  return answer === true;
}

/* ------------------------------------------------------------------ */
/* Φόρμες                                                              */
/* ------------------------------------------------------------------ */

export const options = (list, selected) => list.map(({ value, label }) =>
  `<option value="${esc(value)}"${String(value) === String(selected ?? '') ? ' selected' : ''}>${esc(label)}</option>`
).join('');

export const val = (dlg, id) => dlg.querySelector(`#${id}`)?.value.trim() ?? '';
export const numVal = (dlg, id) => Number(dlg.querySelector(`#${id}`)?.value) || 0;

export const PAYMENT_METHODS = [
  { value: '', label: '—' },
  { value: 'cash', label: 'Μετρητά' },
  { value: 'card', label: 'Κάρτα' },
  { value: 'bank', label: 'Τράπεζα' }
];

export const paymentLabel = (value) =>
  PAYMENT_METHODS.find((m) => m.value === value)?.label ?? '—';

export const BUSINESS_LABELS = {
  cafe: 'Καφετέρια',
  video: 'Βίντεο',
  rooms: 'Καταλύματα'
};

export const businessChip = (code) =>
  `<span class="chip ${esc(code)}">${esc(BUSINESS_LABELS[code] || code)}</span>`;
