/** Ημερήσιο ταμείο καφετέριας: τρία ανεξάρτητα μεγέθη ανά ημέρα. */
import * as db from '../db.js';
import * as sync from '../sync.js';
import * as auth from '../auth.js';
import {
  num, esc, icon, toast, card, statCard, emptyState,
  eur, isoToday, dateGR, weekdayGR, monthLabel
} from '../ui.js';

export const cafeDaily = {
  title: 'Ημερήσιο ταμείο',
  sub: 'Τζίρος, κάρτα και Ζ ανά ημέρα',

  async mount(root) {
    let month = isoToday().slice(0, 7);

    const paint = async () => {
      const rows = (await db.all('cafe_daily'))
        .filter((r) => r.date && r.date.startsWith(month))
        .sort((a, b) => b.date.localeCompare(a.date));

      const sum = (field) => rows.reduce((t, r) => t + (Number(r[field]) || 0), 0);
      const today = rows.find((r) => r.date === isoToday());

      root.innerHTML = `
        <div class="stats-grid">
          ${statCard('Τζίρος μήνα', eur(sum('turnover')), `${rows.length} ημέρες`, 'c-blue')}
          ${statCard('Κάρτα', eur(sum('card')), '', 'c-purple')}
          ${statCard('Ζ', eur(sum('z_reading')), '', 'c-green')}
          ${statCard('Σήμερα', today ? eur(today.turnover) : '—',
                     today ? 'καταχωρήθηκε' : 'εκκρεμεί', today ? 'c-green' : 'c-orange')}
        </div>

        ${card('Καταχώρηση ημέρας', `
          <form id="dayForm" autocomplete="off">
            <div class="field-row">
              <div class="field">
                <label for="fDate">Ημερομηνία</label>
                <input type="date" id="fDate" value="${isoToday()}" max="${isoToday()}" required>
              </div>
              <div class="field">
                <label for="fTurnover">Τζίρος</label>
                <input type="number" id="fTurnover" step="0.01" min="0" placeholder="0,00" required>
              </div>
            </div>
            <div class="field-row">
              <div class="field">
                <label for="fCard">Κάρτα</label>
                <input type="number" id="fCard" step="0.01" min="0" placeholder="0,00" required>
              </div>
              <div class="field">
                <label for="fZ">Ζ</label>
                <input type="number" id="fZ" step="0.01" min="0" placeholder="0,00" required>
              </div>
            </div>
            <div class="field">
              <label for="fNote">Σημείωση</label>
              <input type="text" id="fNote" placeholder="Προαιρετικά">
            </div>
            <button type="submit" class="btn btn-primary">${icon('save')} Αποθήκευση ημέρας</button>
            <p class="hint" id="dayHint" style="margin-top:8px;font-size:.7rem;color:var(--text3)"></p>
          </form>`, { sub: 'Αν η ημέρα υπάρχει ήδη, η καταχώρηση την ενημερώνει' })}

        ${card(monthLabel(`${month}-01`), `
          <div class="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Ημερομηνία</th><th>Ημέρα</th>
                  <th class="num">Τζίρος</th><th class="num">Κάρτα</th><th class="num">Ζ</th>
                  <th>Σημείωση</th><th></th>
                </tr>
              </thead>
              <tbody>
                ${rows.length ? rows.map((r) => `
                  <tr>
                    <td>${dateGR(r.date)}</td>
                    <td style="color:var(--text3)">${weekdayGR(r.date)}</td>
                    <td class="num">${num(r.turnover)}</td>
                    <td class="num">${num(r.card)}</td>
                    <td class="num">${num(r.z_reading)}</td>
                    <td style="color:var(--text3)">${esc(r.note || '')}</td>
                    <td><button class="btn btn-sm" data-edit="${esc(r.id)}">Άνοιγμα</button></td>
                  </tr>`).join('') : `
                  <tr><td colspan="7">${emptyState('Καμία καταχώρηση αυτόν τον μήνα',
                      'Συμπλήρωσε την πρώτη ημέρα από τη φόρμα πιο πάνω.')}</td></tr>`}
              </tbody>
              ${rows.length ? `
              <tfoot>
                <tr style="font-weight:700;background:var(--bg4)">
                  <td colspan="2">Σύνολο</td>
                  <td class="num">${num(sum('turnover'))}</td>
                  <td class="num">${num(sum('card'))}</td>
                  <td class="num">${num(sum('z_reading'))}</td>
                  <td colspan="2"></td>
                </tr>
              </tfoot>` : ''}
            </table>
          </div>`, {
            actions: `
              <button class="btn btn-sm" id="prevMonth">← Προηγούμενος</button>
              <button class="btn btn-sm" id="nextMonth">Επόμενος →</button>`
          })}
      `;

      /* ---- γεγονότα ---- */

      const form = root.querySelector('#dayForm');
      const hint = root.querySelector('#dayHint');
      const fDate = root.querySelector('#fDate');

      const showExisting = async () => {
        const match = (await db.all('cafe_daily')).find((r) => r.date === fDate.value);
        if (match) {
          root.querySelector('#fTurnover').value = match.turnover ?? '';
          root.querySelector('#fCard').value = match.card ?? '';
          root.querySelector('#fZ').value = match.z_reading ?? '';
          root.querySelector('#fNote').value = match.note ?? '';
          hint.textContent = 'Η ημέρα έχει ήδη καταχωρηθεί. Η αποθήκευση θα την ενημερώσει.';
        } else {
          hint.textContent = '';
        }
      };

      fDate.addEventListener('change', showExisting);
      await showExisting();

      form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const date = fDate.value;
        const existing = (await db.all('cafe_daily')).find((r) => r.date === date);

        await db.put('cafe_daily', {
          id: existing?.id,
          date,
          turnover: Number(root.querySelector('#fTurnover').value) || 0,
          card: Number(root.querySelector('#fCard').value) || 0,
          z_reading: Number(root.querySelector('#fZ').value) || 0,
          note: root.querySelector('#fNote').value.trim() || null
        }, { user_id: auth.user()?.id });

        toast(existing ? 'Η ημέρα ενημερώθηκε' : 'Η ημέρα αποθηκεύτηκε', 'ok');
        sync.run({ silent: true });
        month = date.slice(0, 7);
        await paint();
      });

      root.querySelectorAll('[data-edit]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const row = await db.get('cafe_daily', btn.dataset.edit);
          if (!row) return;
          fDate.value = row.date;
          await showExisting();
          root.querySelector('#dayForm').scrollIntoView({ block: 'center' });
        });
      });

      const shift = (delta) => {
        const [y, m] = month.split('-').map(Number);
        const d = new Date(y, m - 1 + delta, 1);
        month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        paint();
      };
      root.querySelector('#prevMonth')?.addEventListener('click', () => shift(-1));
      root.querySelector('#nextMonth')?.addEventListener('click', () => shift(1));
    };

    await paint();
    return paint;
  }
};
