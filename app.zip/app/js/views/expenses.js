/**
 * Έξοδα. Η ίδια οθόνη εξυπηρετεί και τα συνολικά και μία μόνο επιχείρηση,
 * γι' αυτό επιστρέφεται από εργοστάσιο αντί να γραφτεί δύο φορές.
 */
import * as db from '../db.js';
import * as sync from '../sync.js';
import * as auth from '../auth.js';
import {
  eur, num, esc, icon, toast, card, statCard, emptyState, modal, options,
  val, numVal, confirmDialog, isoToday, dateGR, monthLabel,
  PAYMENT_METHODS, paymentLabel, BUSINESS_LABELS, businessChip
} from '../ui.js';

/* ------------------------------------------------------------------ */
/* Κατηγορίες                                                          */
/* ------------------------------------------------------------------ */

/** Κατηγορίες σε σειρά γονιού-παιδιού, για λίστες και πτυσσόμενα. */
export function categoryTree(categories, business = null) {
  const usable = categories.filter(
    (c) => c.active !== false && (!business || !c.business || c.business === business)
  );
  const roots = usable.filter((c) => !c.parent_id).sort((a, b) => a.name.localeCompare(b.name, 'el'));

  const out = [];
  for (const root of roots) {
    out.push({ ...root, depth: 0 });
    usable
      .filter((c) => c.parent_id === root.id)
      .sort((a, b) => a.name.localeCompare(b.name, 'el'))
      .forEach((child) => out.push({ ...child, depth: 1 }));
  }
  return out;
}

const categoryOptions = (categories, business, selected) => [
  { value: '', label: 'Χωρίς κατηγορία' },
  ...categoryTree(categories, business).map((c) => ({
    value: c.id,
    label: (c.depth ? '   ' : '') + c.name
  }))
];

export const categoryName = (categories, id) =>
  categories.find((c) => c.id === id)?.name || '—';

/* ------------------------------------------------------------------ */
/* Φόρμα                                                               */
/* ------------------------------------------------------------------ */

/** Ανοίγει τη φόρμα εξόδου. Επιστρέφει true αν αποθηκεύτηκε. */
export async function expenseForm({ expense = null, business = null, prefill = {} } = {}) {
  const categories = await db.all('expense_categories');
  const current = expense || { ...prefill };
  const biz = current.business || business || 'cafe';

  const body = `
    <div class="field-row">
      <div class="field">
        <label for="eDate">Ημερομηνία</label>
        <input type="date" id="eDate" value="${esc(current.date || isoToday())}" required>
      </div>
      <div class="field">
        <label for="eAmount">Ποσό</label>
        <input type="number" id="eAmount" step="0.01" min="0" inputmode="decimal"
               value="${current.amount ?? ''}" placeholder="0,00" required>
      </div>
    </div>
    <div class="field-row">
      <div class="field">
        <label for="eBusiness">Επιχείρηση</label>
        <select id="eBusiness" ${business ? 'disabled' : ''}>
          ${options(Object.entries(BUSINESS_LABELS).map(([value, label]) => ({ value, label })), biz)}
        </select>
      </div>
      <div class="field">
        <label for="eCategory">Κατηγορία</label>
        <select id="eCategory">${options(categoryOptions(categories, null, current.category_id))}</select>
      </div>
    </div>
    <div class="field">
      <label for="eDesc">Περιγραφή</label>
      <input id="eDesc" value="${esc(current.description || '')}" placeholder="π.χ. Τροφοδοσία εβδομάδας" required>
    </div>
    <div class="field-row">
      <div class="field">
        <label for="ePay">Τρόπος πληρωμής</label>
        <select id="ePay">${options(PAYMENT_METHODS, current.payment_method)}</select>
      </div>
      <div class="field">
        <label for="eNote">Σημείωση</label>
        <input id="eNote" value="${esc(current.note || '')}" placeholder="Προαιρετικά">
      </div>
    </div>`;

  const saved = await modal({
    title: expense ? 'Επεξεργασία εξόδου' : 'Νέο έξοδο',
    body,
    async onSave(dlg) {
      const amount = numVal(dlg, 'eAmount');
      if (amount <= 0) throw new Error('Το ποσό πρέπει να είναι μεγαλύτερο από μηδέν');
      const description = val(dlg, 'eDesc');
      if (!description) throw new Error('Συμπλήρωσε μια περιγραφή');

      await db.put('expenses', {
        id: expense?.id,
        business: business || val(dlg, 'eBusiness'),
        category_id: val(dlg, 'eCategory') || null,
        date: val(dlg, 'eDate'),
        description,
        amount,
        payment_method: val(dlg, 'ePay') || null,
        note: val(dlg, 'eNote') || null,
        recurring_id: current.recurring_id || null,
        // Συμπληρώνονται από τα τιμολόγια προμηθευτών στη φάση 3.
        amount_net: expense?.amount_net ?? null,
        vat_amount: expense?.vat_amount ?? null,
        supplier_id: expense?.supplier_id ?? null,
        invoice_id: expense?.invoice_id ?? null
      }, { user_id: auth.user()?.id });

      return true;
    }
  });

  if (saved) {
    toast(expense ? 'Το έξοδο ενημερώθηκε' : 'Το έξοδο καταχωρήθηκε', 'ok');
    sync.run({ silent: true });
  }
  return saved === true;
}

/* ------------------------------------------------------------------ */
/* Οθόνη                                                               */
/* ------------------------------------------------------------------ */

export function expensesView({ business = null, title = 'Έξοδα', sub = '' } = {}) {
  return {
    title,
    sub,

    async mount(root) {
      let month = isoToday().slice(0, 7);
      let categoryFilter = '';

      const paint = async () => {
        const categories = await db.all('expense_categories');
        const all = await db.all('expenses');

        const rows = all
          .filter((e) => !business || e.business === business)
          .filter((e) => e.date?.startsWith(month))
          .filter((e) => !categoryFilter || e.category_id === categoryFilter)
          .sort((a, b) => b.date.localeCompare(a.date));

        const total = rows.reduce((t, e) => t + (Number(e.amount) || 0), 0);

        const perCategory = {};
        for (const e of rows) {
          const key = e.category_id || '—';
          perCategory[key] = (perCategory[key] || 0) + (Number(e.amount) || 0);
        }
        const [topId, topSum] = Object.entries(perCategory).sort((a, b) => b[1] - a[1])[0] || [];

        root.innerHTML = `
          <div class="stats-grid">
            ${statCard('Σύνολο μήνα', eur(total), monthLabel(`${month}-01`), 'c-blue')}
            ${statCard('Καταχωρήσεις', String(rows.length), '', 'c-purple')}
            ${statCard('Μεγαλύτερη κατηγορία',
                       topId ? categoryName(categories, topId) : '—',
                       topId ? eur(topSum) : '', 'c-orange')}
          </div>

          <div class="filters">
            <button class="btn btn-sm" id="prevMonth">←</button>
            <span style="font-weight:700;font-size:.82rem">${monthLabel(`${month}-01`)}</span>
            <button class="btn btn-sm" id="nextMonth">→</button>
            <select id="catFilter">
              ${options([{ value: '', label: 'Όλες οι κατηγορίες' },
                         ...categoryTree(categories, business).map((c) => ({
                           value: c.id, label: (c.depth ? '   ' : '') + c.name
                         }))], categoryFilter)}
            </select>
            <div class="spacer"></div>
            <button class="btn btn-primary btn-sm" id="addExpense">Νέο έξοδο</button>
          </div>

          ${card('Κινήσεις', `
            <div class="table-wrap">
              <table>
                <thead>
                  <tr>
                    <th>Ημ/νία</th>
                    ${business ? '' : '<th>Επιχείρηση</th>'}
                    <th>Κατηγορία</th><th>Περιγραφή</th><th>Πληρωμή</th>
                    <th class="num">Ποσό</th><th></th>
                  </tr>
                </thead>
                <tbody>
                  ${rows.length ? rows.map((e) => `
                    <tr>
                      <td>${dateGR(e.date)}</td>
                      ${business ? '' : `<td>${businessChip(e.business)}</td>`}
                      <td>${esc(categoryName(categories, e.category_id))}</td>
                      <td>${esc(e.description)}${e.recurring_id ? ' <span class="chip">πάγιο</span>' : ''}</td>
                      <td class="muted">${esc(paymentLabel(e.payment_method))}</td>
                      <td class="num">${num(e.amount)}</td>
                      <td>
                        <div class="row-actions">
                          <button class="btn btn-sm" data-edit="${esc(e.id)}">Άνοιγμα</button>
                          <button class="btn btn-sm btn-danger" data-del="${esc(e.id)}">Διαγραφή</button>
                        </div>
                      </td>
                    </tr>`).join('') : `
                    <tr><td colspan="${business ? 6 : 7}">
                      ${emptyState('Κανένα έξοδο αυτόν τον μήνα',
                                   'Πάτα «Νέο έξοδο» για την πρώτη καταχώρηση.')}
                    </td></tr>`}
                </tbody>
                ${rows.length ? `
                <tfoot>
                  <tr style="font-weight:700;background:var(--bg4)">
                    <td colspan="${business ? 4 : 5}">Σύνολο</td>
                    <td class="num">${num(total)}</td><td></td>
                  </tr>
                </tfoot>` : ''}
              </table>
            </div>`)}
        `;

        root.querySelector('#addExpense').addEventListener('click', async () => {
          if (await expenseForm({ business })) await paint();
        });

        root.querySelector('#catFilter').addEventListener('change', (e) => {
          categoryFilter = e.target.value;
          paint();
        });

        const shift = (delta) => {
          const [y, m] = month.split('-').map(Number);
          const d = new Date(y, m - 1 + delta, 1);
          month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
          paint();
        };
        root.querySelector('#prevMonth').addEventListener('click', () => shift(-1));
        root.querySelector('#nextMonth').addEventListener('click', () => shift(1));

        root.querySelectorAll('[data-edit]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const expense = await db.get('expenses', btn.dataset.edit);
            if (expense && await expenseForm({ expense, business })) await paint();
          });
        });

        root.querySelectorAll('[data-del]').forEach((btn) => {
          btn.addEventListener('click', async () => {
            const expense = await db.get('expenses', btn.dataset.del);
            if (!expense) return;
            const ok = await confirmDialog(
              'Διαγραφή εξόδου',
              `Να διαγραφεί το έξοδο «${expense.description}» των ${eur(expense.amount)};`
            );
            if (!ok) return;
            await db.remove('expenses', expense.id, { user_id: auth.user()?.id });
            toast('Το έξοδο διαγράφηκε', 'ok');
            sync.run({ silent: true });
            await paint();
          });
        });
      };

      await paint();
      return paint;
    }
  };
}
