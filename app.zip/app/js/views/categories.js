/**
 * Κατηγορίες εξόδων. Δύο επίπεδα: κατηγορία και υποκατηγορία.
 * Οι κατηγορίες φτιάχνονται από τον χρήστη. Το έτοιμο σύνολο προσφέρεται
 * μία φορά, με κουμπί, αντί να εμφανιστεί μόνο του από το πουθενά.
 */
import * as db from '../db.js';
import * as sync from '../sync.js';
import * as auth from '../auth.js';
import {
  esc, toast, card, emptyState, modal, options, val, confirmDialog,
  BUSINESS_LABELS, businessChip
} from '../ui.js';
import { categoryTree } from './expenses.js';

const STARTERS = [
  { business: 'cafe',  name: 'Τροφοδοσία' },
  { business: 'cafe',  name: 'Ποτά' },
  { business: 'cafe',  name: 'Αναλώσιμα' },
  { business: 'cafe',  name: 'Μισθοδοσία' },
  { business: 'cafe',  name: 'Εξοπλισμός' },
  { business: 'video', name: 'Εξοπλισμός' },
  { business: 'video', name: 'Λογισμικό & συνδρομές' },
  { business: 'video', name: 'Μετακινήσεις' },
  { business: 'video', name: 'Συνεργάτες' },
  { business: null,    name: 'Ενοίκιο' },
  { business: null,    name: 'ΔΕΚΟ' },
  { business: null,    name: 'Συντήρηση' },
  { business: null,    name: 'Διάφορα' }
];

async function categoryForm({ category = null, categories = [] } = {}) {
  const roots = categories.filter((c) => !c.parent_id && c.id !== category?.id && c.active !== false);

  const body = `
    <div class="field">
      <label for="cName">Όνομα</label>
      <input id="cName" value="${esc(category?.name || '')}" required placeholder="π.χ. Τροφοδοσία">
    </div>
    <div class="field">
      <label for="cBusiness">Επιχείρηση</label>
      <select id="cBusiness">
        ${options([{ value: '', label: 'Κοινή και για τις τρεις' },
                   ...Object.entries(BUSINESS_LABELS).map(([value, label]) => ({ value, label }))],
                  category?.business || '')}
      </select>
    </div>
    <div class="field">
      <label for="cParent">Ανήκει σε</label>
      <select id="cParent">
        ${options([{ value: '', label: 'Καμία, είναι κύρια κατηγορία' },
                   ...roots.map((c) => ({ value: c.id, label: c.name }))],
                  category?.parent_id || '')}
      </select>
      <div class="hint">Δύο επίπεδα το πολύ.</div>
    </div>`;

  return modal({
    title: category ? 'Επεξεργασία κατηγορίας' : 'Νέα κατηγορία',
    body,
    async onSave(dlg) {
      const name = val(dlg, 'cName');
      if (!name) throw new Error('Συμπλήρωσε όνομα');

      const parentId = val(dlg, 'cParent') || null;
      const duplicate = categories.find(
        (c) => c.id !== category?.id &&
               c.name.toLowerCase() === name.toLowerCase() &&
               (c.parent_id || null) === parentId
      );
      if (duplicate) throw new Error('Υπάρχει ήδη κατηγορία με αυτό το όνομα στο ίδιο επίπεδο');

      await db.put('expense_categories', {
        id: category?.id,
        name,
        business: val(dlg, 'cBusiness') || null,
        parent_id: parentId,
        active: category?.active ?? true
      }, { user_id: auth.user()?.id });

      return true;
    }
  });
}

export const categoriesView = {
  title: 'Κατηγορίες εξόδων',
  sub: 'Πώς ομαδοποιούνται τα έξοδά σου',

  async mount(root) {
    const paint = async () => {
      const categories = await db.all('expense_categories');
      const expenses = await db.all('expenses');
      const tree = categoryTree(categories);
      const usage = (id) => expenses.filter((e) => e.category_id === id).length;

      root.innerHTML = `
        <div class="filters">
          <div class="spacer"></div>
          <button class="btn btn-primary btn-sm" id="addCat">Νέα κατηγορία</button>
        </div>

        ${card('Κατηγορίες', `
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Όνομα</th><th>Επιχείρηση</th><th class="num">Κινήσεις</th><th></th></tr>
              </thead>
              <tbody>
                ${tree.length ? tree.map((c) => `
                  <tr class="${c.depth ? 'tree-child' : ''}">
                    <td>${c.depth ? '<span class="muted">└ </span>' : ''}${esc(c.name)}</td>
                    <td>${c.business ? businessChip(c.business) : '<span class="muted">Κοινή</span>'}</td>
                    <td class="num">${usage(c.id)}</td>
                    <td>
                      <div class="row-actions">
                        <button class="btn btn-sm" data-edit="${esc(c.id)}">Άνοιγμα</button>
                        <button class="btn btn-sm btn-danger" data-del="${esc(c.id)}">Διαγραφή</button>
                      </div>
                    </td>
                  </tr>`).join('') : `
                  <tr><td colspan="4">
                    ${emptyState('Δεν υπάρχουν κατηγορίες ακόμα',
                                 'Φτιάξε τις δικές σου, ή ξεκίνα από ένα έτοιμο σύνολο και άλλαξέ το.')}
                    <div style="text-align:center;padding-bottom:18px">
                      <button class="btn" id="seed">Πρόσθεσε βασικές κατηγορίες</button>
                    </div>
                  </td></tr>`}
              </tbody>
            </table>
          </div>`)}
      `;

      root.querySelector('#addCat').addEventListener('click', async () => {
        if (await categoryForm({ categories })) { toast('Η κατηγορία δημιουργήθηκε', 'ok'); await paint(); }
      });

      root.querySelector('#seed')?.addEventListener('click', async () => {
        for (const starter of STARTERS) {
          await db.put('expense_categories', { ...starter, parent_id: null, active: true },
                       { user_id: auth.user()?.id });
        }
        toast(`Προστέθηκαν ${STARTERS.length} κατηγορίες`, 'ok');
        sync.run({ silent: true });
        await paint();
      });

      root.querySelectorAll('[data-edit]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const category = await db.get('expense_categories', btn.dataset.edit);
          if (category && await categoryForm({ category, categories })) {
            toast('Η κατηγορία ενημερώθηκε', 'ok');
            await paint();
          }
        });
      });

      root.querySelectorAll('[data-del]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const id = btn.dataset.del;
          const category = await db.get('expense_categories', id);
          if (!category) return;

          const used = usage(id);
          const children = categories.filter((c) => c.parent_id === id && c.active !== false).length;

          if (children) {
            await modal({
              title: 'Δεν γίνεται διαγραφή',
              body: `<p style="font-size:.85rem;color:var(--text2)">Η κατηγορία «${esc(category.name)}»
                     έχει ${children} υποκατηγορίες. Διάγραψε πρώτα εκείνες.</p>`,
              saveLabel: 'Εντάξει', cancelLabel: 'Κλείσιμο', onSave: () => true
            });
            return;
          }

          const message = used
            ? `${used} έξοδα ανήκουν σε αυτή την κατηγορία. Θα μείνουν, αλλά χωρίς κατηγορία. Συνέχεια;`
            : `Να διαγραφεί η κατηγορία «${category.name}»;`;
          if (!(await confirmDialog('Διαγραφή κατηγορίας', message))) return;

          await db.remove('expense_categories', id, { user_id: auth.user()?.id });
          toast('Η κατηγορία διαγράφηκε', 'ok');
          sync.run({ silent: true });
          await paint();
        });
      });
    };

    await paint();
    return paint;
  }
};
