/**
 * Μητρώο οθονών. Το κλειδί εδώ πρέπει να ταιριάζει με το key του μενού.
 * Ό,τι δεν βρίσκεται εδώ, εμφανίζει οθόνη αναμονής με τη φάση του.
 */
import { findItem } from '../menu.js';
import { placeholder } from '../ui.js';

import { dashboard } from './dashboard.js';
import { cafeDaily } from './cafe-daily.js';
import { systemSync, systemUsers, systemSettings } from './system.js';
import { expensesView } from './expenses.js';
import { categoriesView } from './categories.js';
import { recurringView } from './recurring.js';
import { videoLedger } from './ledger.js';

export const VIEWS = {
  dashboard,

  // καφετέρια
  'cafe/daily': cafeDaily,
  'cafe/expenses': expensesView({
    business: 'cafe',
    title: 'Έξοδα καφετέριας',
    sub: 'Τροφοδοσία, αναλώσιμα, λειτουργικά'
  }),

  // βίντεο
  'video/ledger': videoLedger,

  // κοινά
  expenses: expensesView({ title: 'Όλα τα έξοδα', sub: 'Και για τις τρεις επιχειρήσεις' }),
  'expenses/categories': categoriesView,
  'expenses/recurring': recurringView,

  // σύστημα
  'system/sync': systemSync,
  'system/users': systemUsers,
  'system/settings': systemSettings
};

const PHASE_NOTES = {
  3: 'Έρχεται μαζί με τους προμηθευτές και την ανάγνωση τιμολογίων.',
  4: 'Έρχεται μαζί με τις λίστες παραγγελίας.',
  5: 'Έρχεται μαζί με τις συνταγές και το food cost.',
  6: 'Έρχεται με τη μεταφορά των καταλυμάτων.',
  7: 'Έρχεται με τις αναφορές και τα αντίγραφα.'
};

export function placeholderView(key) {
  const item = findItem(key);
  return {
    title: item?.label || 'Οθόνη',
    sub: 'Δεν έχει υλοποιηθεί ακόμα',
    async mount(root) {
      root.innerHTML = placeholder(
        item?.label || 'Οθόνη',
        PHASE_NOTES[item?.phase] || 'Θα προστεθεί σε επόμενη φάση.',
        item?.phase ?? '—'
      );
    }
  };
}
