/**
 * Κινήσεις εταιρείας βίντεο: έσοδα και έξοδα σε μία λίστα.
 * Δεν υπάρχουν έργα και πελάτες ακόμα, όπως συμφωνήθηκε.
 */
import * as db from '../db.js';
import * as sync from '../sync.js';
import * as auth from '../auth.js';
import {
  eur, num, esc, toast, card, statCard, emptyState, modal, options, val, numVal,
  confirmDialog, isoToday, dateGR, monthLabel, PAYMENT_METHODS, paymentLabel
} from '../ui.js';
import { categoryTree, categoryName, expenseForm } from './expenses.js';

const BUSINESS = 'video';

async function incomeForm({ income = null } = {}) {
  const body = `
    <div class="field-row">
      <div class="field">
        <label for="iDate">Ημερομηνία</label>
        <input type="date" id="iDate" value="${esc(income?.date || isoToday())}" required>
      </div>
      <div class="field">
        <label for="iAmount">Ποσό</label>
        <input type="number" id="iAmount" step="0.01" min="0" inputmode="decimal"
               value="${income?.amount ?? ''}" placeholder="0,00" required>
      </div>
    </div>
    <div class="field">
      <label for="iDesc">Περιγραφή</label>
      <input id="iDesc" value="${esc(income?.description || '')}" required
             placeholder="π.χ. Γάμος Παπαδόπουλου, δεύτερη δόση">
    </div>
    <div class="field-row">
      <div class="field">
        <label for="iPay">Τρόπος πληρωμής</label>
        <select id="iPay">${options(PAYMENT_METHODS, income?.payment_method)}</select>
      </div>
      <div class="field">
        <label for="iNote">Σημείωση</label>
        <input id="iNote" value="${esc(income?.note || '')}" placeholder="Προαιρετικά">
      </div>
    </div>`;

  const saved = await modal({
    title: income ? 'Επεξεργασία εσόδου' : 'Νέο έσοδο',
    body,
    async onSave(dlg) {
      const amount = numVal(dlg, 'iAmount');
      if (amount <= 0) throw new Error('Το ποσό πρέπει να είναι μεγαλύτερο από μηδέν');
      const description = val(dlg, 'iDesc');
      if (!description) throw new Error('Συμπλήρωσε μια περιγραφή');

      await db.put('income', {
        id: income?.id,
        business: BUSINESS,
        date: val(dlg, 'iDate'),
        description,
        amount,
        payment_method: val(dlg, 'iPay') || null,
        note: val(dlg, 'iNote') || null,
        category_id: income?.category_id ?? null
      }, { user_id: auth.user()?.id });

      return true;
    }
  });

  if (saved) {
    toast(income ? 'Το έσοδο ενημερώθηκε' : 'Το έσοδο καταχωρήθηκε', 'ok');
    sync.run({ silent: true });
  }
  return saved === true;
}

export const videoLedger = {
  title: 'Κινήσεις',
  sub: 'Έσοδα και έξοδα παραγωγής βίντεο',

  async mount(root) {
    let month = isoToday().slice(0, 7);

    const paint = async () => {
      const categories = await db.all('expense_categories');

      const income = (await db.all('income'))
        .filter((r) => r.business === BUSINESS && r.date?.startsWith(month))
        .map((r) => ({ ...r, kind: 'income' }));

      const expenses = (await db.all('expenses'))
        .filter((r) => r.business === BUSINESS && r.date?.startsWith(month))
        .map((r) => ({ ...r, kind: 'expense' }));

      const rows = [...income, ...expenses].sort((a, b) => b.date.localeCompare(a.date));
      const totalIn = income.reduce((t, r) => t + (Number(r.amount) || 0), 0);
      const totalOut = expenses.reduce((t, r) => t + (Number(r.amount) || 0), 0);
      const balance = totalIn - totalOut;

      root.innerHTML = `
        <div class="stats-grid">
          ${statCard('Έσοδα', eur(totalIn), monthLabel(`${month}-01`), 'c-green')}
          ${statCard('Έξοδα', eur(totalOut), '', 'c-orange')}
          ${statCard('Διαφορά', eur(balance), balance >= 0 ? 'θετική' : 'αρνητική',
                     balance >= 0 ? 'c-blue' : 'c-red')}
          ${statCard('Κινήσεις', String(rows.length), '', 'c-purple')}
        </div>

        <div class="filters">
          <button class="btn btn-sm" id="prevMonth">←</button>
          <span style="font-weight:700;font-size:.82rem">${monthLabel(`${month}-01`)}</span>
          <button class="btn btn-sm" id="nextMonth">→</button>
          <div class="spacer"></div>
          <button class="btn btn-sm" id="addExpense">Νέο έξοδο</button>
          <button class="btn btn-primary btn-sm" id="addIncome">Νέο έσοδο</button>
        </div>

        ${card('Κινήσεις μήνα', `
          <div class="table-wrap">
            <table>
              <thead>
                <tr><th>Ημ/νία</th><th>Είδος</th><th>Περιγραφή</th><th>Κατηγορία</th>
                    <th>Πληρωμή</th><th class="num">Ποσό</th><th></th></tr>
              </thead>
              <tbody>
                ${rows.length ? rows.map((r) => `
                  <tr>
                    <td>${dateGR(r.date)}</td>
                    <td><span class="chip ${r.kind === 'income' ? 'rooms' : ''}">
                      ${r.kind === 'income' ? 'Έσοδο' : 'Έξοδο'}</span></td>
                    <td>${esc(r.description)}</td>
                    <td class="muted">${r.kind === 'expense' ? esc(categoryName(categories, r.category_id)) : '—'}</td>
                    <td class="muted">${esc(paymentLabel(r.payment_method))}</td>
                    <td class="num" style="color:${r.kind === 'income' ? 'var(--green)' : 'var(--text)'}">
                      ${r.kind === 'income' ? '+' : '−'}${num(r.amount)}</td>
                    <td><div class="row-actions">
                      <button class="btn btn-sm" data-edit="${esc(r.id)}" data-kind="${r.kind}">Άνοιγμα</button>
                      <button class="btn btn-sm btn-danger" data-del="${esc(r.id)}" data-kind="${r.kind}">Διαγραφή</button>
                    </div></td>
                  </tr>`).join('') : `
                  <tr><td colspan="7">
                    ${emptyState('Καμία κίνηση αυτόν τον μήνα',
                                 'Καταχώρησε το πρώτο έσοδο ή έξοδο.')}
                  </td></tr>`}
              </tbody>
            </table>
          </div>`)}
      `;

      root.querySelector('#addIncome').addEventListener('click', async () => {
        if (await incomeForm()) await paint();
      });
      root.querySelector('#addExpense').addEventListener('click', async () => {
        if (await expenseForm({ business: BUSINESS })) await paint();
      });

      const shift = (delta) => {
        const [y, m] = month.split('-').map(Number);
        const d = new Date(y, m - 1 + delta, 1);
        month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
        paint();
      };
      root.querySelector('#prevMonth').addEventListener('click', () => shift(-1));
      root.querySelector('#nextMonth').addEventListener('click', () => shift(1));

      root.querySelectorAll('[data-edit]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const { edit, kind } = btn.dataset;
          if (kind === 'income') {
            const record = await db.get('income', edit);
            if (record && await incomeForm({ income: record })) await paint();
          } else {
            const record = await db.get('expenses', edit);
            if (record && await expenseForm({ expense: record, business: BUSINESS })) await paint();
          }
        });
      });

      root.querySelectorAll('[data-del]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const { del, kind } = btn.dataset;
          const table = kind === 'income' ? 'income' : 'expenses';
          const record = await db.get(table, del);
          if (!record) return;
          if (!(await confirmDialog('Διαγραφή κίνησης',
                `Να διαγραφεί «${record.description}» των ${eur(record.amount)};`))) return;
          await db.remove(table, del, { user_id: auth.user()?.id });
          toast('Η κίνηση διαγράφηκε', 'ok');
          sync.run({ silent: true });
          await paint();
        });
      });
    };

    await paint();
    return paint;
  }
};
