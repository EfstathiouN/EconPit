/** Οθόνες συστήματος: συγχρονισμός, χρήστες, ρυθμίσεις. */
import * as db from '../db.js';
import * as sync from '../sync.js';
import * as auth from '../auth.js';
import { CONFIG, isSyncConfigured } from '../config.js';
import { esc, icon, toast, card, statCard, emptyState, relativeTime } from '../ui.js';

export const systemSync = {
  title: 'Συγχρονισμός',
  sub: 'Κατάσταση και χειροκίνητος έλεγχος',

  async mount(root) {
    const paint = async () => {
      const { state, lastError, lastSyncAt } = sync.getState();
      const pending = await db.outbox.count();
      const labels = {
        local: 'Τοπική λειτουργία', offline: 'Χωρίς δίκτυο', syncing: 'Σε εξέλιξη',
        synced: 'Ενημερωμένο', error: 'Σφάλμα'
      };

      root.innerHTML = `
        ${!isSyncConfigured() ? `
          <div class="msg warn">
            Ο συγχρονισμός δεν έχει ρυθμιστεί. Τα δεδομένα μένουν σε αυτή τη συσκευή.
            Συμπλήρωσε <strong>url</strong> και <strong>anonKey</strong> στο αρχείο
            <code>js/config.js</code> και κάνε επαναφόρτωση.
          </div>` : ''}

        <div class="stats-grid">
          ${statCard('Κατάσταση', labels[state] || state, lastError || '', state === 'error' ? 'c-orange' : 'c-green')}
          ${statCard('Εκκρεμείς εγγραφές', String(pending), 'στην ουρά αποστολής', 'c-blue')}
          ${statCard('Τελευταία επιτυχία', relativeTime(lastSyncAt), '', 'c-purple')}
        </div>

        ${card('Ενέργειες', `
          <div class="topbar-actions" style="flex-wrap:wrap">
            <button class="btn btn-primary" id="runNow" ${isSyncConfigured() ? '' : 'disabled'}>
              ${icon('refresh')} Συγχρονισμός τώρα
            </button>
            <button class="btn" id="fullPull" ${isSyncConfigured() ? '' : 'disabled'}>
              Πλήρες ξανακατέβασμα
            </button>
          </div>
          <p style="font-size:.72rem;color:var(--text3);margin-top:10px">
            Το πλήρες ξανακατέβασμα φέρνει όλες τις εγγραφές από την αρχή. Χρήσιμο μόνο
            αν κάτι δεν συμφωνεί ανάμεσα σε δύο συσκευές.
          </p>`)}
      `;

      root.querySelector('#runNow')?.addEventListener('click', async (e) => {
        e.target.disabled = true;
        const result = await sync.run();
        toast(result.error ? 'Ο συγχρονισμός απέτυχε' : 'Ολοκληρώθηκε', result.error ? 'err' : 'ok');
        await paint();
      });

      root.querySelector('#fullPull')?.addEventListener('click', async (e) => {
        e.target.disabled = true;
        await sync.resetCursors();
        toast('Τα δεδομένα ξανακατέβηκαν', 'ok');
        await paint();
      });
    };

    await paint();
    return paint;
  }
};

export const systemUsers = {
  title: 'Χρήστες & δικαιώματα',
  sub: 'Ποιος μπαίνει και τι βλέπει',

  async mount(root) {
    const profiles = await db.all('profiles');
    const me = auth.user();

    root.innerHTML = `
      ${card('Λογαριασμοί', `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Όνομα</th><th>Email</th><th>Ρόλος</th><th>Κατάσταση</th></tr></thead>
            <tbody>
              ${profiles.length ? profiles.map((p) => `
                <tr>
                  <td>${esc(p.name)}${p.id === me?.id ? ' <span style="color:var(--text3)">(εσύ)</span>' : ''}</td>
                  <td>${esc(p.email || '—')}</td>
                  <td>${p.role === 'owner' ? 'Ιδιοκτήτης' : 'Υπάλληλος'}</td>
                  <td>${p.active === false ? 'Ανενεργός' : 'Ενεργός'}</td>
                </tr>`).join('') : `
                <tr><td colspan="4">${emptyState('Κανένας άλλος λογαριασμός',
                    'Οι λογαριασμοί υπαλλήλων δημιουργούνται από τον Supabase.')}</td></tr>`}
            </tbody>
          </table>
        </div>`)}

      ${card('Τι βλέπει ο υπάλληλος', `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Οθόνη</th><th>Ιδιοκτήτης</th><th>Υπάλληλος</th></tr></thead>
            <tbody>
              <tr><td>Ημερήσιο ταμείο</td><td>Πλήρης</td><td>Δεν εμφανίζεται</td></tr>
              <tr><td>Τιμολόγια προμηθευτών</td><td>Πλήρης</td><td>Καταχώρηση, χωρίς έγκριση</td></tr>
              <tr><td>Λίστες παραγγελίας</td><td>Πλήρης</td><td>Προσθήκη ειδών</td></tr>
              <tr><td>Πρώτες ύλες</td><td>Πλήρης</td><td>Μόνο ανάγνωση</td></tr>
              <tr><td>Όλα τα υπόλοιπα</td><td>Πλήρης</td><td>Δεν εμφανίζονται</td></tr>
            </tbody>
          </table>
        </div>`, { sub: 'Ο περιορισμός επιβάλλεται και από τον server, όχι μόνο από το μενού' })}
    `;
  }
};

export const systemSettings = {
  title: 'Ρυθμίσεις',
  sub: 'Συσκευή και τοπικά δεδομένα',

  async mount(root) {
    const counts = await db.stats();
    const device = await db.deviceId();
    const rows = Object.entries(counts).filter(([, n]) => n > 0);

    root.innerHTML = `
      ${card('Αυτή η συσκευή', `
        <div class="field"><label>Αναγνωριστικό συσκευής</label>
          <input value="${esc(device)}" readonly></div>
        <div class="field"><label>Συγχρονισμός</label>
          <input value="${isSyncConfigured() ? CONFIG.SUPABASE.url : 'Δεν έχει ρυθμιστεί'}" readonly></div>`)}

      ${card('Τοπικά δεδομένα', `
        <div class="table-wrap">
          <table>
            <thead><tr><th>Πίνακας</th><th class="num">Εγγραφές</th></tr></thead>
            <tbody>
              ${rows.length ? rows.map(([t, n]) => `
                <tr><td>${esc(t)}</td><td class="num">${n}</td></tr>`).join('') : `
                <tr><td colspan="2">${emptyState('Άδεια βάση', 'Δεν έχει καταχωρηθεί τίποτα ακόμα.')}</td></tr>`}
            </tbody>
          </table>
        </div>`)}

      ${card('Καθαρισμός', `
        <p style="font-size:.78rem;color:var(--text2);margin-bottom:12px">
          Σβήνει τα δεδομένα από αυτή τη συσκευή. Ό,τι έχει ήδη συγχρονιστεί ξανακατεβαίνει.
          Ό,τι δεν πρόλαβε να φύγει, χάνεται.
        </p>
        <button class="btn btn-danger" id="wipe">Καθαρισμός συσκευής</button>`)}
    `;

    root.querySelector('#wipe')?.addEventListener('click', async () => {
      const pending = await db.outbox.count();
      const warning = pending
        ? `Υπάρχουν ${pending} εγγραφές που δεν έχουν σταλεί και θα χαθούν. Συνέχεια;`
        : 'Να σβηστούν τα τοπικά δεδομένα;';
      if (!confirm(warning)) return;
      await db.wipe();
      toast('Η συσκευή καθαρίστηκε', 'ok');
      location.reload();
    });
  }
};
