/** Συνολική εικόνα. */
import * as db from '../db.js';
import { isSyncConfigured } from '../config.js';
import { eur, card, statCard, isoToday, monthLabel, relativeTime } from '../ui.js';

export const dashboard = {
  title: 'Πίνακας ελέγχου',
  sub: 'Συνολική εικόνα',

  async mount(root) {
    const days = await db.all('cafe_daily');
    const month = isoToday().slice(0, 7);
    const thisMonth = days.filter((d) => d.date?.startsWith(month));
    const turnover = thisMonth.reduce((t, d) => t + (Number(d.turnover) || 0), 0);
    const lastSync = await db.meta.get('last_sync_at');
    const pending = await db.outbox.count();

    root.innerHTML = `
      <div class="stats-grid">
        ${statCard('Τζίρος καφετέριας', eur(turnover), monthLabel(`${month}-01`), 'c-blue')}
        ${statCard('Ημέρες καταχωρημένες', String(thisMonth.length), 'αυτόν τον μήνα', 'c-green')}
        ${statCard('Εκκρεμούν αποστολή', String(pending), pending ? 'θα φύγουν με το δίκτυο' : 'όλα εστάλησαν', pending ? 'c-orange' : 'c-green')}
        ${statCard('Τελευταίος συγχρονισμός', relativeTime(lastSync), isSyncConfigured() ? '' : 'τοπική λειτουργία', 'c-purple')}
      </div>

      ${card('Πού βρισκόμαστε', `
        <p style="font-size:.82rem;color:var(--text2);line-height:1.7">
          Ο σκελετός, η είσοδος με ρόλους και ο συγχρονισμός είναι στη θέση τους.
          Το ημερήσιο ταμείο δουλεύει κανονικά και αποθηκεύει τοπικά, ακόμα και χωρίς δίκτυο.
          Οι υπόλοιπες οθόνες ανοίγουν και δείχνουν σε ποια φάση έρχονται.
        </p>`)}
    `;
  }
};
