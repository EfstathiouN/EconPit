/**
 * Πάγια και συνδρομές.
 *
 * Το ποσό αλλάζει κάθε μήνα, οπότε δεν δημιουργούμε έξοδα αυτόματα. Κρατάμε
 * το πρότυπο και υπενθυμίζουμε ποια δεν έχουν περαστεί ακόμα αυτόν τον μήνα.
 */
import * as db from '../db.js';
import * as sync from '../sync.js';
import * as auth from '../auth.js';
import {
  eur, num, esc, toast, card, statCard, emptyState, modal, options, val, numVal,
  confirmDialog, isoToday, monthLabel, BUSINESS_LABELS, businessChip
} from '../ui.js';
import { categoryTree, categoryName, expenseForm } from './expenses.js';

/**
 * Ποια πάγια δεν έχουν καταχωρηθεί για τον μήνα.
 * Καθαρή συνάρτηση, ώστε να ελέγχεται με δοκιμές χωρίς βάση.
 */
export function pendingRecurring(templates, expenses, month, today = isoToday()) {
  const dayNow = Number(today.slice(8, 10));
  const sameMonth = today.slice(0, 7) === month;

  return templates
    .filter((t) => t.active !== false)
    .filter((t) => !expenses.some((e) => e.recurring_id === t.id && e.date?.startsWith(month)))
    .map((t) => ({
      ...t,
      overdue: sameMonth ? dayNow > (t.day_of_month || 1) : month < today.slice(0, 7)
    }))
    .sort((a, b) => (a.day_of_month || 1) - (b.day_of_month || 1));
}

async function recurringForm({ template = null, categories = [] } = {}) {
  const body = `
    <div class="field">
      <label for="rName">Όνομα</label>
      <input id="rName" value="${esc(template?.name || '')}" required placeholder="π.χ. ΔΕΗ καφετέριας">
    </div>
    <div class="field-row">
      <div class="field">
        <label for="rBusiness">Επιχείρηση</label>
        <select id="rBusiness">
          ${options(Object.entries(BUSINESS_LABELS).map(([value, label]) => ({ value, label })),
                    template?.business || 'cafe')}
        </select>
      </div>
      <div class="field">
        <label for="rDay">Ημέρα του μήνα</label>
        <input type="number" id="rDay" min="1" max="31" value="${template?.day_of_month || 1}" required>
      </div>
    </div>
    <div class="field-row">
      <div class="field">
        <label for="rCategory">Κατηγορία</label>
        <select id="rCategory">
          ${options([{ value: '', label: 'Χωρίς κατηγορία' },
                     ...categoryTree(categories).map((c) => ({
                       value: c.id, label: (c.depth ? '   ' : '') + c.name
                     }))], template?.category_id)}
        </select>
      </div>
      <div class="field">
        <label for="rEstimate">Ενδεικτικό ποσό</label>
        <input type="number" id="rEstimate" step="0.01" min="0"
               value="${template?.estimated_amount ?? ''}" placeholder="0,00">
        <div class="hint">Μόνο για προσανατολισμό.</div>
      </div>
    </div>`;

  return modal({
    title: template ? 'Επεξεργασία παγίου' : 'Νέο πάγιο',
    body,
    async onSave(dlg) {
      const name = val(dlg, 'rName');
      if (!name) throw new Error('Συμπλήρωσε όνομα');

      const day = Number(val(dlg, 'rDay'));
      if (day < 1 || day > 31) throw new Error('Η ημέρα πρέπει να είναι από 1 έως 31');

      await db.put('recurring_expenses', {
        id: template?.id,
        name,
        business: val(dlg, 'rBusiness'),
        category_id: val(dlg, 'rCategory') || null,
        day_of_month: day,
        estimated_amount: numVal(dlg, 'rEstimate') || null,
        active: template?.active ?? true
      }, { user_id: auth.user()?.id });

      return true;
    }
  });
}

export const recurringView = {
  title: 'Πάγια & συνδρομές',
  sub: 'Τι πληρώνεις κάθε μήνα και τι λείπει ακόμα',

  async mount(root) {
    const month = isoToday().slice(0, 7);

    const paint = async () => {
      const templates = await db.all('recurring_expenses');
      const expenses = await db.all('expenses');
      const categories = await db.all('expense_categories');
      const pending = pendingRecurring(templates, expenses, month);

      const paidThisMonth = expenses.filter(
        (e) => e.recurring_id && e.date?.startsWith(month)
      );
      const paidTotal = paidThisMonth.reduce((t, e) => t + (Number(e.amount) || 0), 0);

      root.innerHTML = `
        <div class="stats-grid">
          ${statCard('Ενεργά πάγια', String(templates.filter((t) => t.active !== false).length), '', 'c-blue')}
          ${statCard('Περιμένουν καταχώρηση', String(pending.length),
                     pending.filter((p) => p.overdue).length ? 'κάποια έχουν περάσει' : '',
                     pending.length ? 'c-orange' : 'c-green')}
          ${statCard('Πληρωμένα τον μήνα', eur(paidTotal), monthLabel(`${month}-01`), 'c-green')}
        </div>

        ${pending.length ? card(`Εκκρεμούν για ${monthLabel(`${month}-01`)}`, `
          <div class="table-wrap">
            <table>
              <thead><tr><th>Πάγιο</th><th>Επιχείρηση</th><th>Ημέρα</th>
                         <th class="num">Ενδεικτικά</th><th></th></tr></thead>
              <tbody>
                ${pending.map((t) => `
                  <tr>
                    <td>${esc(t.name)}
                      ${t.overdue ? '<span class="chip due">πέρασε η ημέρα</span>' : ''}</td>
                    <td>${businessChip(t.business)}</td>
                    <td>${t.day_of_month}</td>
                    <td class="num">${t.estimated_amount ? num(t.estimated_amount) : '—'}</td>
                    <td><div class="row-actions">
                      <button class="btn btn-sm btn-primary" data-pay="${esc(t.id)}">Καταχώρηση</button>
                    </div></td>
                  </tr>`).join('')}
              </tbody>
            </table>
          </div>`, { sub: 'Πάτα καταχώρηση και συμπλήρωσε το πραγματικό ποσό' }) : ''}

        <div class="filters">
          <div class="spacer"></div>
          <button class="btn btn-primary btn-sm" id="addRec">Νέο πάγιο</button>
        </div>

        ${card('Όλα τα πάγια', `
          <div class="table-wrap">
            <table>
              <thead><tr><th>Όνομα</th><th>Επιχείρηση</th><th>Κατηγορία</th>
                         <th>Ημέρα</th><th class="num">Ενδεικτικά</th><th></th></tr></thead>
              <tbody>
                ${templates.length ? templates
                  .sort((a, b) => (a.day_of_month || 1) - (b.day_of_month || 1))
                  .map((t) => `
                    <tr${t.active === false ? ' class="muted"' : ''}>
                      <td>${esc(t.name)}${t.active === false ? ' <span class="chip">ανενεργό</span>' : ''}</td>
                      <td>${businessChip(t.business)}</td>
                      <td>${esc(categoryName(categories, t.category_id))}</td>
                      <td>${t.day_of_month}</td>
                      <td class="num">${t.estimated_amount ? num(t.estimated_amount) : '—'}</td>
                      <td><div class="row-actions">
                        <button class="btn btn-sm" data-edit="${esc(t.id)}">Άνοιγμα</button>
                        <button class="btn btn-sm btn-danger" data-del="${esc(t.id)}">Διαγραφή</button>
                      </div></td>
                    </tr>`).join('') : `
                  <tr><td colspan="6">
                    ${emptyState('Κανένα πάγιο ακόμα',
                                 'Πρόσθεσε ενοίκιο, ΔΕΗ, ασφάλειες, συνδρομές.')}
                  </td></tr>`}
              </tbody>
            </table>
          </div>`)}
      `;

      root.querySelector('#addRec').addEventListener('click', async () => {
        if (await recurringForm({ categories })) { toast('Το πάγιο δημιουργήθηκε', 'ok'); await paint(); }
      });

      root.querySelectorAll('[data-pay]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const template = await db.get('recurring_expenses', btn.dataset.pay);
          if (!template) return;

          const done = await expenseForm({
            business: template.business,
            prefill: {
              description: template.name,
              category_id: template.category_id,
              amount: template.estimated_amount ?? '',
              recurring_id: template.id,
              date: `${month}-${String(template.day_of_month).padStart(2, '0')}`
            }
          });
          if (done) await paint();
        });
      });

      root.querySelectorAll('[data-edit]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const template = await db.get('recurring_expenses', btn.dataset.edit);
          if (template && await recurringForm({ template, categories })) {
            toast('Το πάγιο ενημερώθηκε', 'ok');
            await paint();
          }
        });
      });

      root.querySelectorAll('[data-del]').forEach((btn) => {
        btn.addEventListener('click', async () => {
          const template = await db.get('recurring_expenses', btn.dataset.del);
          if (!template) return;
          if (!(await confirmDialog('Διαγραφή παγίου',
                `Να διαγραφεί το «${template.name}»; Τα έξοδα που έχεις ήδη καταχωρήσει μένουν.`))) return;
          await db.remove('recurring_expenses', template.id, { user_id: auth.user()?.id });
          toast('Το πάγιο διαγράφηκε', 'ok');
          sync.run({ silent: true });
          await paint();
        });
      });
    };

    await paint();
    return paint;
  }
};
