/**
 * Τοπική βάση (IndexedDB).
 *
 * Κάθε εγγραφή φέρει πέντε πεδία υποδομής:
 *   id, updated_at, deleted, device_id, created_by
 *
 * Η εφαρμογή γράφει ΠΑΝΤΑ εδώ πρώτα. Ο συγχρονισμός είναι ξεχωριστό βήμα.
 *
 * Προσθήκη νέου πίνακα: γράψε τον στο TABLES και ανέβασε το DB_VERSION κατά ένα.
 * Τα υπάρχοντα δεδομένα δεν πειράζονται.
 */

const DB_NAME = 'biz';
const DB_VERSION = 1;

/** Πίνακες δεδομένων και τα ευρετήριά τους. */
export const TABLES = {
  // κοινά
  businesses:         { indexes: [] },
  profiles:           { indexes: [] },
  expense_categories: { indexes: ['business_id'] },
  expenses:           { indexes: ['business_id', 'date', 'status'] },
  income:             { indexes: ['business_id', 'date'] },

  // καφετέρια
  cafe_daily:         { indexes: ['date'] },
  suppliers:          { indexes: ['name'] },
  supplier_invoices:  { indexes: ['supplier_id', 'invoice_date', 'status'] },
  invoice_lines:      { indexes: ['invoice_id', 'product_id'] },
  products:           { indexes: ['name', 'category'] },
  product_aliases:    { indexes: ['supplier_id'] },
  product_prices:     { indexes: ['product_id', 'date'] },
  recipes:            { indexes: ['name'] },
  recipe_items:       { indexes: ['recipe_id'] },
  order_lists:        { indexes: ['supplier_id', 'status'] },
  order_list_items:   { indexes: ['order_list_id'] }
};

/** Εσωτερικοί πίνακες: δεν συγχρονίζονται ποτέ. */
const SYSTEM_STORES = ['_outbox', '_meta'];

let _db = null;

/* ------------------------------------------------------------------ */
/* Άνοιγμα                                                             */
/* ------------------------------------------------------------------ */

export function open() {
  if (_db) return Promise.resolve(_db);

  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);

    req.onupgradeneeded = (e) => {
      const db = e.target.result;

      for (const [name, def] of Object.entries(TABLES)) {
        if (db.objectStoreNames.contains(name)) continue;
        const store = db.createObjectStore(name, { keyPath: 'id' });
        store.createIndex('updated_at', 'updated_at');
        for (const idx of def.indexes || []) store.createIndex(idx, idx);
      }

      if (!db.objectStoreNames.contains('_outbox')) {
        const ob = db.createObjectStore('_outbox', { keyPath: 'key', autoIncrement: true });
        ob.createIndex('table', 'table');
      }
      if (!db.objectStoreNames.contains('_meta')) {
        db.createObjectStore('_meta', { keyPath: 'key' });
      }
    };

    req.onsuccess = () => { _db = req.result; resolve(_db); };
    req.onerror   = () => reject(req.error);
  });
}

function tx(stores, mode) {
  return _db.transaction(stores, mode);
}

function done(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror   = () => reject(request.error);
  });
}

/* ------------------------------------------------------------------ */
/* Βοηθητικά                                                           */
/* ------------------------------------------------------------------ */

export function uuid() {
  if (crypto.randomUUID) return crypto.randomUUID();
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
    const r = (Math.random() * 16) | 0;
    return (c === 'x' ? r : (r & 0x3) | 0x8).toString(16);
  });
}

export async function deviceId() {
  const found = await meta.get('device_id');
  if (found) return found;
  const id = uuid();
  await meta.set('device_id', id);
  return id;
}

/* ------------------------------------------------------------------ */
/* Μεταδεδομένα                                                        */
/* ------------------------------------------------------------------ */

export const meta = {
  async get(key) {
    await open();
    const row = await done(tx(['_meta'], 'readonly').objectStore('_meta').get(key));
    return row ? row.value : null;
  },
  async set(key, value) {
    await open();
    await done(tx(['_meta'], 'readwrite').objectStore('_meta').put({ key, value }));
    return value;
  },
  async remove(key) {
    await open();
    await done(tx(['_meta'], 'readwrite').objectStore('_meta').delete(key));
  }
};

/* ------------------------------------------------------------------ */
/* Ουρά αποστολής                                                      */
/* ------------------------------------------------------------------ */

export const outbox = {
  async add(table, record) {
    await open();
    await done(tx(['_outbox'], 'readwrite').objectStore('_outbox')
      .add({ table, record, queued_at: new Date().toISOString() }));
  },
  async all() {
    await open();
    return done(tx(['_outbox'], 'readonly').objectStore('_outbox').getAll());
  },
  async remove(keys) {
    await open();
    const store = tx(['_outbox'], 'readwrite').objectStore('_outbox');
    await Promise.all(keys.map((k) => done(store.delete(k))));
  },
  async count() {
    await open();
    return done(tx(['_outbox'], 'readonly').objectStore('_outbox').count());
  }
};

/* ------------------------------------------------------------------ */
/* CRUD                                                                */
/* ------------------------------------------------------------------ */

/** Γράφει τοπικά και βάζει την εγγραφή στην ουρά αποστολής. */
export async function put(table, data, ctx = {}) {
  await open();
  const now = new Date().toISOString();

  const record = {
    ...data,
    id: data.id || uuid(),
    updated_at: now,
    deleted: data.deleted === true,
    device_id: ctx.device_id || (await deviceId()),
    created_by: data.created_by || ctx.user_id || null
  };

  await done(tx([table], 'readwrite').objectStore(table).put(record));
  await outbox.add(table, record);
  return record;
}

/** Γράφει χωρίς να μπει στην ουρά. Το χρησιμοποιεί μόνο ο συγχρονισμός. */
export async function putRemote(table, record) {
  await open();
  await done(tx([table], 'readwrite').objectStore(table).put(record));
  return record;
}

export async function get(table, id) {
  await open();
  return done(tx([table], 'readonly').objectStore(table).get(id));
}

export async function all(table, { includeDeleted = false } = {}) {
  await open();
  const rows = await done(tx([table], 'readonly').objectStore(table).getAll());
  return includeDeleted ? rows : rows.filter((r) => !r.deleted);
}

export async function byIndex(table, index, value, { includeDeleted = false } = {}) {
  await open();
  const store = tx([table], 'readonly').objectStore(table);
  const rows = await done(store.index(index).getAll(value));
  return includeDeleted ? rows : rows.filter((r) => !r.deleted);
}

/** Διαγραφή με σήμανση. Η γραμμή μένει ώστε να ταξιδέψει η διαγραφή στις άλλες συσκευές. */
export async function remove(table, id, ctx = {}) {
  const existing = await get(table, id);
  if (!existing) return null;
  return put(table, { ...existing, deleted: true }, ctx);
}

/** Εγγραφές αλλαγμένες μετά από ένα σημείο. */
export async function changedSince(table, isoDate) {
  await open();
  const store = tx([table], 'readonly').objectStore(table);
  const range = IDBKeyRange.lowerBound(isoDate, true);
  return done(store.index('updated_at').getAll(range));
}

/** Σβήνει τα πάντα. Χρησιμοποιείται στην αποσύνδεση και στην επαναφορά. */
export async function wipe({ keepDevice = true } = {}) {
  await open();
  const device = keepDevice ? await meta.get('device_id') : null;
  const names = [...Object.keys(TABLES), ...SYSTEM_STORES];
  const t = tx(names, 'readwrite');
  await Promise.all(names.map((n) => done(t.objectStore(n).clear())));
  if (device) await meta.set('device_id', device);
}

/** Μέγεθος τοπικής βάσης, για την οθόνη ρυθμίσεων. */
export async function stats() {
  await open();
  const out = {};
  for (const name of Object.keys(TABLES)) {
    out[name] = await done(tx([name], 'readonly').objectStore(name).count());
  }
  out._outbox = await outbox.count();
  return out;
}
