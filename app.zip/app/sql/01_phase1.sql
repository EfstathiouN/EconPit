-- =====================================================================
--  Φάση 1 — προφίλ, ρόλοι, ημερήσιο ταμείο
--
--  Εκτέλεση: Supabase → SQL Editor → επικόλληση → Run
--
--  Τα πέντε πεδία υποδομής (id, updated_at, deleted, device_id, created_by)
--  επαναλαμβάνονται σε κάθε πίνακα. Το updated_at έρχεται από τη συσκευή,
--  γιατί αυτό αποφασίζει ποια εκδοχή κερδίζει σε σύγκρουση.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Προφίλ χρηστών
-- ---------------------------------------------------------------------
create table if not exists public.profiles (
  id          uuid primary key references auth.users on delete cascade,
  name        text not null,
  email       text,
  role        text not null default 'staff' check (role in ('owner','staff')),
  active      boolean not null default true,
  updated_at  timestamptz not null default now(),
  deleted     boolean not null default false,
  device_id   text,
  created_by  uuid
);

-- Ο ρόλος του συνδεδεμένου χρήστη, για χρήση μέσα στις πολιτικές.
-- security definer ώστε το διάβασμα του ρόλου να μη μπλοκάρεται από τις ίδιες τις πολιτικές.
create or replace function public.app_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role from public.profiles where id = auth.uid()
$$;

-- ---------------------------------------------------------------------
-- Επιχειρήσεις
-- ---------------------------------------------------------------------
create table if not exists public.businesses (
  id          uuid primary key default gen_random_uuid(),
  code        text not null unique check (code in ('cafe','video','rooms')),
  name        text not null,
  active      boolean not null default true,
  updated_at  timestamptz not null default now(),
  deleted     boolean not null default false,
  device_id   text,
  created_by  uuid
);

insert into public.businesses (code, name) values
  ('cafe',  'Καφετέρια'),
  ('video', 'Παραγωγή βίντεο & φωτογραφίας'),
  ('rooms', 'Ενοικιαζόμενα δωμάτια')
on conflict (code) do nothing;

-- ---------------------------------------------------------------------
-- Ημερήσιο ταμείο καφετέριας
-- ---------------------------------------------------------------------
create table if not exists public.cafe_daily (
  id          uuid primary key,
  date        date not null,
  turnover    numeric(12,2) not null default 0,
  card        numeric(12,2) not null default 0,
  z_reading   numeric(12,2) not null default 0,
  note        text,
  updated_at  timestamptz not null,
  deleted     boolean not null default false,
  device_id   text,
  created_by  uuid
);

-- Μία εγγραφή ανά ημέρα. Το φίλτρο αφήνει έξω τις διαγραμμένες, ώστε μια
-- ημέρα που σβήστηκε να μπορεί να ξανακαταχωρηθεί.
create unique index if not exists cafe_daily_date_uniq
  on public.cafe_daily (date) where deleted = false;

create index if not exists cafe_daily_updated_at_idx on public.cafe_daily (updated_at);
create index if not exists profiles_updated_at_idx   on public.profiles (updated_at);
create index if not exists businesses_updated_at_idx on public.businesses (updated_at);

-- ---------------------------------------------------------------------
-- Πολιτικές πρόσβασης
--
-- Ο περιορισμός του υπαλλήλου δεν είναι διακοσμητικός: το μενού απλώς δεν
-- δείχνει τις οθόνες, ενώ εδώ ο server αρνείται τα δεδομένα.
-- ---------------------------------------------------------------------
alter table public.profiles   enable row level security;
alter table public.businesses enable row level security;
alter table public.cafe_daily enable row level security;

-- Προφίλ: ο καθένας βλέπει το δικό του, ο ιδιοκτήτης όλα.
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select
  using (id = auth.uid() or public.app_role() = 'owner');

drop policy if exists profiles_write on public.profiles;
create policy profiles_write on public.profiles for all
  using (public.app_role() = 'owner')
  with check (public.app_role() = 'owner');

-- Επιχειρήσεις: όλοι διαβάζουν, μόνο ο ιδιοκτήτης γράφει.
drop policy if exists businesses_select on public.businesses;
create policy businesses_select on public.businesses for select
  using (auth.uid() is not null);

drop policy if exists businesses_write on public.businesses;
create policy businesses_write on public.businesses for all
  using (public.app_role() = 'owner')
  with check (public.app_role() = 'owner');

-- Ημερήσιο ταμείο: μόνο ο ιδιοκτήτης, ούτε ανάγνωση για τον υπάλληλο.
drop policy if exists cafe_daily_owner on public.cafe_daily;
create policy cafe_daily_owner on public.cafe_daily for all
  using (public.app_role() = 'owner')
  with check (public.app_role() = 'owner');

-- ---------------------------------------------------------------------
-- Νέος χρήστης → προφίλ
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, name, email, role, updated_at)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'name', split_part(new.email, '@', 1)),
    new.email,
    coalesce(new.raw_user_meta_data->>'role', 'staff'),
    now()
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Μετά την πρώτη εγγραφή χρήστη, δώσε στον εαυτό σου τον ρόλο ιδιοκτήτη:
--
--   update public.profiles set role = 'owner' where email = 'το@email.σου';
-- ---------------------------------------------------------------------
