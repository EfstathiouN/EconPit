-- =====================================================================
--  Φάση 2 — έξοδα, κατηγορίες, έσοδα, πάγια
--
--  Εκτέλεση μετά το 01_phase1.sql.
--
--  Η επιχείρηση γράφεται ως κωδικός κειμένου, όχι ως ξένο κλειδί. Σε τρεις
--  σταθερές επιχειρήσεις το κλειδί θα πρόσθετε μόνο ένα βήμα συγχρονισμού
--  που μπορεί να αποτύχει, χωρίς να κερδίζει τίποτα.
-- =====================================================================

create or replace function public.is_owner() returns boolean
language sql stable as $$ select public.app_role() = 'owner' $$;

-- ---------------------------------------------------------------------
-- Κατηγορίες εξόδων
-- ---------------------------------------------------------------------
create table if not exists public.expense_categories (
  id          uuid primary key,
  name        text not null,
  business    text check (business in ('cafe','video','rooms')),   -- κενό = κοινή
  parent_id   uuid references public.expense_categories(id),
  active      boolean not null default true,
  updated_at  timestamptz not null,
  deleted     boolean not null default false,
  device_id   text,
  created_by  uuid
);

-- ---------------------------------------------------------------------
-- Έξοδα
--
--  Το amount είναι το τελικό ποσό, όπως ζητήθηκε. Τα amount_net και
--  vat_amount μένουν κενά στη χειροκίνητη καταχώρηση και συμπληρώνονται
--  από την ανάγνωση τιμολογίων στη φάση 3, όπου τα χρειάζεται το food cost.
-- ---------------------------------------------------------------------
create table if not exists public.expenses (
  id             uuid primary key,
  business       text not null check (business in ('cafe','video','rooms')),
  category_id    uuid references public.expense_categories(id),
  date           date not null,
  description    text not null,
  amount         numeric(12,2) not null check (amount >= 0),
  amount_net     numeric(12,2),
  vat_amount     numeric(12,2),
  payment_method text check (payment_method in ('cash','card','bank')),
  note           text,
  recurring_id   uuid,
  supplier_id    uuid,
  invoice_id     uuid,
  updated_at     timestamptz not null,
  deleted        boolean not null default false,
  device_id      text,
  created_by     uuid
);

-- ---------------------------------------------------------------------
-- Έσοδα
-- ---------------------------------------------------------------------
create table if not exists public.income (
  id             uuid primary key,
  business       text not null check (business in ('cafe','video','rooms')),
  category_id    uuid,
  date           date not null,
  description    text not null,
  amount         numeric(12,2) not null check (amount >= 0),
  payment_method text check (payment_method in ('cash','card','bank')),
  note           text,
  updated_at     timestamptz not null,
  deleted        boolean not null default false,
  device_id      text,
  created_by     uuid
);

-- ---------------------------------------------------------------------
-- Πάγια
--
--  Δεν δημιουργούν έξοδα μόνα τους. Το ποσό αλλάζει κάθε μήνα, οπότε η
--  εφαρμογή θυμίζει ποια λείπουν και ο χρήστης περνάει το πραγματικό ποσό.
-- ---------------------------------------------------------------------
create table if not exists public.recurring_expenses (
  id               uuid primary key,
  name             text not null,
  business         text not null check (business in ('cafe','video','rooms')),
  category_id      uuid references public.expense_categories(id),
  day_of_month     smallint not null check (day_of_month between 1 and 31),
  estimated_amount numeric(12,2),
  active           boolean not null default true,
  updated_at       timestamptz not null,
  deleted          boolean not null default false,
  device_id        text,
  created_by       uuid
);

-- ---------------------------------------------------------------------
-- Ευρετήρια
-- ---------------------------------------------------------------------
create index if not exists expenses_updated_at_idx   on public.expenses (updated_at);
create index if not exists expenses_date_idx         on public.expenses (business, date);
create index if not exists income_updated_at_idx     on public.income (updated_at);
create index if not exists income_date_idx           on public.income (business, date);
create index if not exists categories_updated_at_idx on public.expense_categories (updated_at);
create index if not exists recurring_updated_at_idx  on public.recurring_expenses (updated_at);

-- ---------------------------------------------------------------------
-- Πρόσβαση: όλα τα οικονομικά είναι μόνο για τον ιδιοκτήτη
-- ---------------------------------------------------------------------
alter table public.expense_categories enable row level security;
alter table public.expenses           enable row level security;
alter table public.income             enable row level security;
alter table public.recurring_expenses enable row level security;

drop policy if exists categories_owner on public.expense_categories;
create policy categories_owner on public.expense_categories for all
  using (public.is_owner()) with check (public.is_owner());

drop policy if exists expenses_owner on public.expenses;
create policy expenses_owner on public.expenses for all
  using (public.is_owner()) with check (public.is_owner());

drop policy if exists income_owner on public.income;
create policy income_owner on public.income for all
  using (public.is_owner()) with check (public.is_owner());

drop policy if exists recurring_owner on public.recurring_expenses;
create policy recurring_owner on public.recurring_expenses for all
  using (public.is_owner()) with check (public.is_owner());
