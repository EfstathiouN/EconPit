/* Service worker: το κέλυφος από την κρυφή μνήμη, ώστε η εφαρμογή να ανοίγει χωρίς δίκτυο. */
const CACHE = 'shell-v2';
const SHELL = [
  './', './index.html', './css/app.css', './manifest.webmanifest',
  './js/app.js', './js/config.js', './js/db.js', './js/api.js',
  './js/auth.js', './js/sync.js', './js/ui.js', './js/menu.js',
  './js/views/index.js', './js/views/dashboard.js', './js/views/cafe-daily.js',
  './js/views/system.js', './js/views/expenses.js', './js/views/categories.js',
  './js/views/recurring.js', './js/views/ledger.js'
];

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener('activate', (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (url.origin !== location.origin) return;   // τα αιτήματα προς τον server δεν αποθηκεύονται

  e.respondWith(
    fetch(e.request)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(e.request, copy));
        return res;
      })
      .catch(() => caches.match(e.request).then((hit) => hit || caches.match('./index.html')))
  );
});
